# MySQL-Front 5.1  (Build 4.13)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;


# Host: localhost    Database: prime
# ------------------------------------------------------
# Server version 5.0.51a-community-nt

#
# Source for table banco
#

DROP TABLE IF EXISTS `banco`;
CREATE TABLE `banco` (
  `COD_BANCO` int(11) NOT NULL auto_increment,
  `NOME_BANCO` varchar(50) default NULL,
  `AGENCIA_BANCO` int(11) default NULL,
  `CONTA_BANCO` int(11) default NULL,
  `GERENTE_BANCO` varchar(20) default NULL,
  `FONE_BANCO` varchar(10) default NULL,
  PRIMARY KEY  (`COD_BANCO`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Dumping data for table banco
#

LOCK TABLES `banco` WRITE;
/*!40000 ALTER TABLE `banco` DISABLE KEYS */;
INSERT INTO `banco` VALUES (1,'BANCO DO BRASIL SA',2585,1234,'Gilberto','6187451234');
INSERT INTO `banco` VALUES (2,'BRADESCO',456,1233,NULL,'456789798');
INSERT INTO `banco` VALUES (7,'UNIBANCO',NULL,12456,'CARLOS','3587-4565');
INSERT INTO `banco` VALUES (9,'SANTANDER',2585,7899,'JOSE','3296-5959');
INSERT INTO `banco` VALUES (10,'HSBC',1066,401592560,'Angelina Jolie','3038-4066');
/*!40000 ALTER TABLE `banco` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cartao
#

DROP TABLE IF EXISTS `cartao`;
CREATE TABLE `cartao` (
  `COD_CARTAO` int(11) NOT NULL auto_increment,
  `NOME_CARTAO` varchar(20) default NULL,
  `TAXA_CARTAO` double(5,2) default NULL,
  PRIMARY KEY  (`COD_CARTAO`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

#
# Dumping data for table cartao
#

LOCK TABLES `cartao` WRITE;
/*!40000 ALTER TABLE `cartao` DISABLE KEYS */;
INSERT INTO `cartao` VALUES (1,'VISA',3.25);
INSERT INTO `cartao` VALUES (2,'MASTERCARD',4.7);
INSERT INTO `cartao` VALUES (5,'teste',5);
INSERT INTO `cartao` VALUES (6,'teste 1',5.9);
/*!40000 ALTER TABLE `cartao` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cfop
#

DROP TABLE IF EXISTS `cfop`;
CREATE TABLE `cfop` (
  `COD_CFOP` int(11) NOT NULL,
  `DESCRICAO_CFOP` text,
  PRIMARY KEY  (`COD_CFOP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table cfop
#

LOCK TABLES `cfop` WRITE;
/*!40000 ALTER TABLE `cfop` DISABLE KEYS */;
INSERT INTO `cfop` VALUES (1101,'Compra para industrializa��o\r');
INSERT INTO `cfop` VALUES (1102,'Compra para comercializa��o\r');
INSERT INTO `cfop` VALUES (1111,'Compra para industrializa��o de mercadoria recebida anteriormente em consigna��o industrial\r');
INSERT INTO `cfop` VALUES (1113,'Compra para comercializa��o, de mercadoria recebida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (1116,'Compra para industrializa��o originada de encomenda para recebimento futuro\r');
INSERT INTO `cfop` VALUES (1117,'Compra para comercializa��o originada de encomenda para recebimento futuro\r');
INSERT INTO `cfop` VALUES (1118,'Compra de mercadoria para comercializa��o pelo adquirente origin�rio, entregue pelo vendedor remetente ao destinat�rio, em venda � ordem\r');
INSERT INTO `cfop` VALUES (1120,'Compra para industrializa��o, em venda � ordem, j� recebida do vendedor remetente\r');
INSERT INTO `cfop` VALUES (1121,'Compra para comercializa��o, em venda � ordem, j� recebida do vendedor remetente\r');
INSERT INTO `cfop` VALUES (1122,'Compra para industrializa��o em que a mercadoria foi remetida pelo fornecedor ao industrializador sem transitar pelo estabelecimento adquirente\r');
INSERT INTO `cfop` VALUES (1124,'Industrializa��o efetuada por outra empresa\r');
INSERT INTO `cfop` VALUES (1125,'Industrializa��o efetuada por outra empresa quando a mercadoria remetida para utiliza��o no processo de industrializa��o n�o transitou pelo estabelecimento adquirente da mercadoria\r');
INSERT INTO `cfop` VALUES (1126,'Compra para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (1151,'Transfer�ncia para industrializa��o\r');
INSERT INTO `cfop` VALUES (1152,'Transfer�ncia para comercializa��o\r');
INSERT INTO `cfop` VALUES (1153,'Transfer�ncia de energia el�trica para distribui��o\r');
INSERT INTO `cfop` VALUES (1154,'Transfer�ncia para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (1201,'Devolu��o de venda de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (1202,'Devolu��o de venda de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (1203,'Devolu��o de venda de produ��o do estabelecimento, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (1204,'Devolu��o de venda de mercadoria adquirida ou recebida de terceiros, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (1205,'Anula��o de valor relativo � presta��o de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (1206,'Anula��o de valor relativo � presta��o de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (1207,'Anula��o de valor relativo � venda de energia el�trica\r');
INSERT INTO `cfop` VALUES (1208,'Devolu��o de produ��o do estabelecimento, remetida em transfer�ncia\r');
INSERT INTO `cfop` VALUES (1209,'Devolu��o de mercadoria adquirida ou recebida de terceiros, remetida em transfer�ncia\r');
INSERT INTO `cfop` VALUES (1251,'Compra de energia el�trica para distribui��o ou comercializa��o\r');
INSERT INTO `cfop` VALUES (1252,'Compra de energia el�trica por estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (1253,'Compra de energia el�trica por estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (1254,'Compra de energia el�trica por estabelecimento prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (1255,'Compra de energia el�trica por estabelecimento prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (1256,'Compra de energia el�trica por estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (1257,'Compra de energia el�trica para consumo por demanda contratada\r');
INSERT INTO `cfop` VALUES (1301,'Aquisi��o de servi�o de comunica��o para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (1302,'Aquisi��o de servi�o de comunica��o por estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (1303,'Aquisi��o de servi�o de comunica��o por estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (1304,'Aquisi��o de servi�o de comunica��o por estabelecimento de prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (1305,'Aquisi��o de servi�o de comunica��o por estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (1306,'Aquisi��o de servi�o de comunica��o por estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (1351,'Aquisi��o de servi�o de transporte para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (1352,'Aquisi��o de servi�o de transporte por estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (1353,'Aquisi��o de servi�o de transporte por estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (1354,'Aquisi��o de servi�o de transporte por estabelecimento de prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (1355,'Aquisi��o de servi�o de transporte por estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (1356,'Aquisi��o de servi�o de transporte por estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (1401,'Compra para industrializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1403,'Compra para comercializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1406,'Compra de bem para o ativo imobilizado cuja mercadoria est� sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1407,'Compra de mercadoria para uso ou consumo cuja mercadoria est� sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1408,'Transfer�ncia para industrializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1409,'Transfer�ncia para comercializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1410,'Devolu��o de venda de produ��o do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1411,'Devolu��o de venda de mercadoria adquirida ou recebida de terceiros em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1414,'Retorno de produ��o do estabelecimento, remetida para venda fora do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1415,'Retorno de mercadoria adquirida ou recebida de terceiros, remetida para venda fora do estabelecimento em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1451,'Retorno de animal do estabelecimento produtor\r');
INSERT INTO `cfop` VALUES (1452,'Retorno de insumo n�o utilizado na produ��o\r');
INSERT INTO `cfop` VALUES (1501,'Entrada de mercadoria recebida com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (1503,'Entrada decorrente de devolu��o de produto remetido com fim espec�fico de exporta��o, de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (1504,'Entrada decorrente de devolu��o de mercadoria remetida com fim espec�fico de exporta��o, adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (1551,'Compra de bem para o ativo imobilizado\r');
INSERT INTO `cfop` VALUES (1552,'Transfer�ncia de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (1553,'Devolu��o de venda de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (1554,'Retorno de bem do ativo imobilizado remetido para uso fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (1555,'Entrada de bem do ativo imobilizado de terceiro, remetido para uso no estabelecimento\r');
INSERT INTO `cfop` VALUES (1556,'Compra de material para uso ou consumo\r');
INSERT INTO `cfop` VALUES (1557,'Transfer�ncia de material para uso ou consumo\r');
INSERT INTO `cfop` VALUES (1601,'Recebimento, por transfer�ncia, de cr�dito de ICMS\r');
INSERT INTO `cfop` VALUES (1602,'Recebimento, por transfer�ncia, de saldo credor de ICMS de outro estabelecimento da mesma empresa, para compensa��o de saldo devedor de ICMS\r');
INSERT INTO `cfop` VALUES (1603,'Ressarcimento de ICMS retido por substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (1604,'Lan�amento do cr�dito relativo � compra de bem para o ativo imobilizado\r');
INSERT INTO `cfop` VALUES (1901,'Entrada para industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (1902,'Retorno de mercadoria remetida para industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (1903,'Entrada de mercadoria remetida para industrializa��o e n�o aplicada no referido processo\r');
INSERT INTO `cfop` VALUES (1904,'Retorno de remessa para venda fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (1905,'Entrada de mercadoria recebida para dep�sito em dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (1906,'Retorno de mercadoria remetida para dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (1907,'Retorno simb�lico de mercadoria remetida para dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (1908,'Entrada de bem por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (1909,'Retorno de bem remetido por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (1910,'Entrada de bonifica��o, doa��o ou brinde\r');
INSERT INTO `cfop` VALUES (1911,'Entrada de amostra gr�tis\r');
INSERT INTO `cfop` VALUES (1912,'Entrada de mercadoria ou bem recebido para demonstra��o\r');
INSERT INTO `cfop` VALUES (1913,'Retorno de mercadoria ou bem remetido para demonstra��o\r');
INSERT INTO `cfop` VALUES (1914,'Retorno de mercadoria ou bem remetido para exposi��o ou feira\r');
INSERT INTO `cfop` VALUES (1915,'Entrada de mercadoria ou bem recebido para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (1916,'Retorno de mercadoria ou bem remetido para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (1917,'Entrada de mercadoria recebida em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (1918,'Devolu��o de mercadoria remetida em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (1919,'Devolu��o simb�lica de mercadoria vendida ou utilizada em processo industrial, remetida anteriormente em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (1920,'Entrada de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (1921,'Retorno de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (1922,'Lan�amento efetuado a t�tulo de simples faturamento decorrente de compra para recebimento futuro\r');
INSERT INTO `cfop` VALUES (1923,'Entrada de mercadoria recebida do vendedor remetente, em venda � ordem\r');
INSERT INTO `cfop` VALUES (1924,'Entrada para industrializa��o por conta e ordem do adquirente da mercadoria, quando esta n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (1925,'Retorno de mercadoria remetida para industrializa��o por conta e ordem do adquirente da mercadoria, quando esta n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (1926,'Lan�amento efetuado a t�tulo de reclassifica��o de mercadoria decorrente de forma��o de kit ou de sua desagrega��o\r');
INSERT INTO `cfop` VALUES (1949,'Outra entrada de mercadoria ou presta��o de servi�o n�o especificada\r');
INSERT INTO `cfop` VALUES (2101,'Compra para industrializa��o\r');
INSERT INTO `cfop` VALUES (2102,'Compra para comercializa��o\r');
INSERT INTO `cfop` VALUES (2111,'Compra para industrializa��o de mercadoria recebida anteriormente em consigna��o industrial\r');
INSERT INTO `cfop` VALUES (2113,'Compra para comercializa��o, de mercadoria recebida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (2116,'Compra para industrializa��o originada de encomenda para recebimento futuro\r');
INSERT INTO `cfop` VALUES (2117,'Compra para comercializa��o originada de encomenda para recebimento futuro\r');
INSERT INTO `cfop` VALUES (2118,'Compra de mercadoria para comercializa��o pelo adquirente origin�rio, entregue pelo vendedor remetente ao destinat�rio, em venda � ordem\r');
INSERT INTO `cfop` VALUES (2120,'Compra para industrializa��o, em venda � ordem, j� recebida do vendedor remetente\r');
INSERT INTO `cfop` VALUES (2121,'Compra para comercializa��o, em venda � ordem, j� recebida do vendedor remetente\r');
INSERT INTO `cfop` VALUES (2122,'Compra para industrializa��o em que a mercadoria foi remetida pelo fornecedor ao industrializador sem transitar pelo estabelecimento adquirente\r');
INSERT INTO `cfop` VALUES (2124,'Industrializa��o efetuada por outra empresa\r');
INSERT INTO `cfop` VALUES (2125,'Industrializa��o efetuada por outra empresa quando a mercadoria remetida para utiliza��o no processo de industrializa��o n�o transitou pelo estabelecimento adquirente da mercadoria\r');
INSERT INTO `cfop` VALUES (2126,'Compra para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (2151,'Transfer�ncia para industrializa��o\r');
INSERT INTO `cfop` VALUES (2152,'Transfer�ncia para comercializa��o\r');
INSERT INTO `cfop` VALUES (2153,'Transfer�ncia de energia el�trica para distribui��o\r');
INSERT INTO `cfop` VALUES (2154,'Transfer�ncia para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (2201,'Devolu��o de venda de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (2202,'Devolu��o de venda de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (2203,'Devolu��o de venda de produ��o do estabelecimento, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (2204,'Devolu��o de venda de mercadoria adquirida ou recebida de terceiros, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (2205,'Anula��o de valor relativo � presta��o de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (2206,'Anula��o de valor relativo � presta��o de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (2207,'Anula��o de valor relativo � venda de energia el�trica\r');
INSERT INTO `cfop` VALUES (2208,'Devolu��o de produ��o do estabelecimento, remetida em transfer�ncia\r');
INSERT INTO `cfop` VALUES (2209,'Devolu��o de mercadoria adquirida ou recebida de terceiros, remetida em transfer�ncia\r');
INSERT INTO `cfop` VALUES (2251,'Compra de energia el�trica para distribui��o ou comercializa��o\r');
INSERT INTO `cfop` VALUES (2252,'Compra de energia el�trica por estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (2253,'Compra de energia el�trica por estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (2254,'Compra de energia el�trica por estabelecimento prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (2255,'Compra de energia el�trica por estabelecimento prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (2256,'Compra de energia el�trica por estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (2257,'Compra de energia el�trica para consumo por demanda contratada\r');
INSERT INTO `cfop` VALUES (2301,'Aquisi��o de servi�o de comunica��o para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (2302,'Aquisi��o de servi�o de comunica��o por estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (2303,'Aquisi��o de servi�o de comunica��o por estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (2304,'Aquisi��o de servi�o de comunica��o por estabelecimento de prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (2305,'Aquisi��o de servi�o de comunica��o por estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (2306,'Aquisi��o de servi�o de comunica��o por estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (2351,'Aquisi��o de servi�o de transporte para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (2352,'Aquisi��o de servi�o de transporte por estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (2353,'Aquisi��o de servi�o de transporte por estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (2354,'Aquisi��o de servi�o de transporte por estabelecimento de prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (2355,'Aquisi��o de servi�o de transporte por estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (2356,'Aquisi��o de servi�o de transporte por estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (2401,'Compra para industrializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2403,'Compra para comercializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2406,'Compra de bem para o ativo imobilizado cuja mercadoria est� sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2407,'Compra de mercadoria para uso ou consumo cuja mercadoria est� sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2408,'Transfer�ncia para industrializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2409,'Transfer�ncia para comercializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2410,'Devolu��o de venda de produ��o do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2411,'Devolu��o de venda de mercadoria adquirida ou recebida de terceiros em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2414,'Retorno de produ��o do estabelecimento, remetida para venda fora do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2415,'Retorno de mercadoria adquirida ou recebida de terceiros, remetida para venda fora do estabelecimento em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2501,'Entrada de mercadoria recebida com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (2503,'Entrada decorrente de devolu��o de produto remetido com fim espec�fico de exporta��o, de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (2504,'Entrada decorrente de devolu��o de mercadoria remetida com fim espec�fico de exporta��o, adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (2551,'Compra de bem para o ativo imobilizado\r');
INSERT INTO `cfop` VALUES (2552,'Transfer�ncia de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (2553,'Devolu��o de venda de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (2554,'Retorno de bem do ativo imobilizado remetido para uso fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (2555,'Entrada de bem do ativo imobilizado de terceiro, remetido para uso no estabelecimento\r');
INSERT INTO `cfop` VALUES (2556,'Compra de material para uso ou consumo\r');
INSERT INTO `cfop` VALUES (2557,'Transfer�ncia de material para uso ou consumo\r');
INSERT INTO `cfop` VALUES (2603,'Ressarcimento de ICMS retido por substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (2901,'Entrada para industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (2902,'Retorno de mercadoria remetida para industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (2903,'Entrada de mercadoria remetida para industrializa��o e n�o aplicada no referido processo\r');
INSERT INTO `cfop` VALUES (2904,'Retorno de remessa para venda fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (2905,'Entrada de mercadoria recebida para dep�sito em dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (2906,'Retorno de mercadoria remetida para dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (2907,'Retorno simb�lico de mercadoria remetida para dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (2908,'Entrada de bem por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (2909,'Retorno de bem remetido por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (2910,'Entrada de bonifica��o, doa��o ou brinde\r');
INSERT INTO `cfop` VALUES (2911,'Entrada de amostra gr�tis\r');
INSERT INTO `cfop` VALUES (2912,'Entrada de mercadoria ou bem recebido para demonstra��o\r');
INSERT INTO `cfop` VALUES (2913,'Retorno de mercadoria ou bem remetido para demonstra��o\r');
INSERT INTO `cfop` VALUES (2914,'Retorno de mercadoria ou bem remetido para exposi��o ou feira\r');
INSERT INTO `cfop` VALUES (2915,'Entrada de mercadoria ou bem recebido para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (2916,'Retorno de mercadoria ou bem remetido para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (2917,'Entrada de mercadoria recebida em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (2918,'Devolu��o de mercadoria remetida em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (2919,'Devolu��o simb�lica de mercadoria vendida ou utilizada em processo industrial, remetida anteriormente em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (2920,'Entrada de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (2921,'Retorno de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (2922,'Lan�amento efetuado a t�tulo de simples faturamento decorrente de compra para recebimento futuro\r');
INSERT INTO `cfop` VALUES (2923,'Entrada de mercadoria recebida do vendedor remetente, em venda � ordem\r');
INSERT INTO `cfop` VALUES (2924,'Entrada para industrializa��o por conta e ordem do adquirente da mercadoria, quando esta n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (2925,'Retorno de mercadoria remetida para industrializa��o por conta e ordem do adquirente da mercadoria, quando esta n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (2949,'Outra entrada de mercadoria ou presta��o de servi�o n�o especificado\r');
INSERT INTO `cfop` VALUES (3101,'Compra para industrializa��o\r');
INSERT INTO `cfop` VALUES (3102,'Compra para comercializa��o\r');
INSERT INTO `cfop` VALUES (3126,'Compra para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (3127,'Compra para industrializa��o sob o regime de drawback\r');
INSERT INTO `cfop` VALUES (3201,'Devolu��o de venda de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (3202,'Devolu��o de venda de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (3205,'Anula��o de valor relativo � presta��o de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (3206,'Anula��o de valor relativo � presta��o de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (3207,'Anula��o de valor relativo � venda de energia el�trica\r');
INSERT INTO `cfop` VALUES (3211,'Devolu��o de venda de produ��o do estabelecimento sob o regime de drawback\r');
INSERT INTO `cfop` VALUES (3251,'Compra de energia el�trica para distribui��o ou comercializa��o\r');
INSERT INTO `cfop` VALUES (3301,'Aquisi��o de servi�o de comunica��o para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (3351,'Aquisi��o de servi�o de transporte para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (3352,'Aquisi��o de servi�o de transporte por estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (3353,'Aquisi��o de servi�o de transporte por estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (3354,'Aquisi��o de servi�o de transporte por estabelecimento de prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (3355,'Aquisi��o de servi�o de transporte por estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (3356,'Aquisi��o de servi�o de transporte por estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (3503,'Devolu��o de mercadoria exportada que tenha sido recebida com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (3551,'Compra de bem para o ativo imobilizado\r');
INSERT INTO `cfop` VALUES (3553,'Devolu��o de venda de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (3556,'Compra de material para uso ou consumo\r');
INSERT INTO `cfop` VALUES (3930,'Lan�amento efetuado a t�tulo de entrada de bem sob amparo de regime especial aduaneiro de admiss�o tempor�ria\r');
INSERT INTO `cfop` VALUES (3949,'Outra entrada de mercadoria ou presta��o de servi�o n�o especificado\r');
INSERT INTO `cfop` VALUES (5101,'Venda de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (5102,'Venda de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (5103,'Venda de produ��o do estabelecimento, efetuada fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (5104,'Venda de mercadoria adquirida ou recebida de terceiros, efetuada fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (5105,'Venda de produ��o do estabelecimento que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (5106,'Venda de mercadoria adquirida ou recebida de terceiros, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (5109,'Venda de produ��o do estabelecimento, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (5110,'Venda de mercadoria adquirida ou recebida de terceiros, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (5111,'Venda de produ��o do estabelecimento remetida anteriormente em consigna��o industrial\r');
INSERT INTO `cfop` VALUES (5112,'Venda de mercadoria adquirida ou recebida de terceiros remetida anteriormente em consigna��o industrial\r');
INSERT INTO `cfop` VALUES (5113,'Venda de produ��o do estabelecimento remetida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (5114,'Venda de mercadoria adquirida ou recebida de terceiros remetida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (5115,'Venda de mercadoria adquirida ou recebida de terceiros, recebida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (5116,'Venda de produ��o do estabelecimento originada de encomenda para entrega futura\r');
INSERT INTO `cfop` VALUES (5117,'Venda de mercadoria adquirida ou recebida de terceiros, originada de encomenda para entrega futura\r');
INSERT INTO `cfop` VALUES (5118,'Venda de produ��o do estabelecimento entregue ao destinat�rio por conta e ordem do adquirente origin�rio, em venda � ordem\r');
INSERT INTO `cfop` VALUES (5119,'Venda de mercadoria adquirida ou recebida de terceiros entregue ao destinat�rio por conta e ordem do adquirente origin�rio, em venda � ordem\r');
INSERT INTO `cfop` VALUES (5120,'Venda de mercadoria adquirida ou recebida de terceiros entregue ao destinat�rio pelo vendedor remetente, em venda � ordem\r');
INSERT INTO `cfop` VALUES (5122,'Venda de produ��o do estabelecimento remetida para industrializa��o, por conta e ordem do adquirente, sem transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (5123,'Venda de mercadoria adquirida ou recebida de terceiros remetida para industrializa��o, por conta e ordem do adquirente, sem transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (5124,'Industrializa��o efetuada para outra empresa\r');
INSERT INTO `cfop` VALUES (5125,'Industrializa��o efetuada para outra empresa quando a mercadoria recebida para utiliza��o no processo de industrializa��o n�o transitar pelo estabelecimento adquirente da mercadoria\r');
INSERT INTO `cfop` VALUES (5151,'Transfer�ncia de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (5152,'Transfer�ncia de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (5153,'Transfer�ncia de energia el�trica\r');
INSERT INTO `cfop` VALUES (5155,'Transfer�ncia de produ��o do estabelecimento, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (5156,'Transfer�ncia de mercadoria adquirida ou recebida de terceiros, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (5201,'Devolu��o de compra para industrializa��o\r');
INSERT INTO `cfop` VALUES (5202,'Devolu��o de compra para comercializa��o\r');
INSERT INTO `cfop` VALUES (5205,'Anula��o de valor relativo a aquisi��o de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (5206,'Anula��o de valor relativo a aquisi��o de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (5207,'Anula��o de valor relativo � compra de energia el�trica\r');
INSERT INTO `cfop` VALUES (5208,'Devolu��o de mercadoria recebida em transfer�ncia para industrializa��o\r');
INSERT INTO `cfop` VALUES (5209,'Devolu��o de mercadoria recebida em transfer�ncia para comercializa��o\r');
INSERT INTO `cfop` VALUES (5210,'Devolu��o de compra para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (5251,'Venda de energia el�trica para distribui��o ou comercializa��o\r');
INSERT INTO `cfop` VALUES (5252,'Venda de energia el�trica para estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (5253,'Venda de energia el�trica para estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (5254,'Venda de energia el�trica para estabelecimento prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (5255,'Venda de energia el�trica para estabelecimento prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (5256,'Venda de energia el�trica para estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (5257,'Venda de energia el�trica para consumo por demanda contratada\r');
INSERT INTO `cfop` VALUES (5258,'Venda de energia el�trica a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (5301,'Presta��o de servi�o de comunica��o para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (5302,'Presta��o de servi�o de comunica��o a estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (5303,'Presta��o de servi�o de comunica��o a estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (5304,'Presta��o de servi�o de comunica��o a estabelecimento de prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (5305,'Presta��o de servi�o de comunica��o a estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (5306,'Presta��o de servi�o de comunica��o a estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (5307,'Presta��o de servi�o de comunica��o a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (5351,'Presta��o de servi�o de transporte para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (5352,'Presta��o de servi�o de transporte a estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (5353,'Presta��o de servi�o de transporte a estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (5354,'Presta��o de servi�o de transporte a estabelecimento de prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (5355,'Presta��o de servi�o de transporte a estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (5356,'Presta��o de servi�o de transporte a estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (5357,'Presta��o de servi�o de transporte a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (5401,'Venda de produ��o do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria, na condi��o de contribuinte substituto\r');
INSERT INTO `cfop` VALUES (5402,'Venda de produ��o do estabelecimento de produto sujeito ao regime de substitui��o tribut�ria, em opera��o entre contribuintes substitutos do mesmo produto\r');
INSERT INTO `cfop` VALUES (5403,'Venda de mercadoria, adquirida ou recebida de terceiros, sujeita ao regime de substitui��o tribut�ria, na condi��o de contribuinte-substituto\r');
INSERT INTO `cfop` VALUES (5405,'Venda de mercadoria, adquirida ou recebida de terceiros, sujeita ao regime de substitui��o tribut�ria, na condi��o de contribuinte-substitu�do\r');
INSERT INTO `cfop` VALUES (5408,'Transfer�ncia de produ��o do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5409,'Transfer�ncia de mercadoria adquirida ou recebida de terceiros em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5410,'Devolu��o de compra para industrializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5411,'Devolu��o de compra para comercializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5412,'Devolu��o de bem do ativo imobilizado, em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5413,'Devolu��o de mercadoria destinada ao uso ou consumo, em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria.\r');
INSERT INTO `cfop` VALUES (5414,'Remessa de produ��o do estabelecimento para venda fora do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5415,'Remessa de mercadoria adquirida ou recebida de terceiros para venda fora do estabelecimento, em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5451,'Remessa de animal e de insumo para estabelecimento produtor\r');
INSERT INTO `cfop` VALUES (5501,'Remessa de produ��o do estabelecimento, com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (5502,'Remessa de mercadoria adquirida ou recebida de terceiros, com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (5503,'Devolu��o de mercadoria recebida com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (5551,'Venda de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (5552,'Transfer�ncia de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (5553,'Devolu��o de compra de bem para o ativo imobilizado\r');
INSERT INTO `cfop` VALUES (5554,'Remessa de bem do ativo imobilizado para uso fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (5555,'Devolu��o de bem do ativo imobilizado de terceiro, recebido para uso no estabelecimento\r');
INSERT INTO `cfop` VALUES (5556,'Devolu��o de compra de material de uso ou consumo\r');
INSERT INTO `cfop` VALUES (5557,'Transfer�ncia de material de uso ou consumo\r');
INSERT INTO `cfop` VALUES (5601,'Transfer�ncia de cr�dito de ICMS acumulado\r');
INSERT INTO `cfop` VALUES (5602,'Transfer�ncia de saldo credor de ICMS para outro estabelecimento da mesma empresa, destinado � compensa��o de saldo devedor de ICMS\r');
INSERT INTO `cfop` VALUES (5603,'Ressarcimento de ICMS retido por substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (5901,'Remessa para industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (5902,'Retorno de mercadoria utilizada na industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (5903,'Retorno de mercadoria recebida para industrializa��o e n�o aplicada no referido processo\r');
INSERT INTO `cfop` VALUES (5904,'Remessa para venda fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (5905,'Remessa para dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (5906,'Retorno de mercadoria depositada em dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (5907,'Retorno simb�lico de mercadoria depositada em dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (5908,'Remessa de bem por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (5909,'Retorno de bem recebido por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (5910,'Remessa em bonifica��o, doa��o ou brinde\r');
INSERT INTO `cfop` VALUES (5911,'Remessa de amostra gr�tis\r');
INSERT INTO `cfop` VALUES (5912,'Remessa de mercadoria ou bem para demonstra��o\r');
INSERT INTO `cfop` VALUES (5913,'Retorno de mercadoria ou bem recebido para demonstra��o\r');
INSERT INTO `cfop` VALUES (5914,'Remessa de mercadoria ou bem para exposi��o ou feira\r');
INSERT INTO `cfop` VALUES (5915,'Remessa de mercadoria ou bem para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (5916,'Retorno de mercadoria ou bem recebido para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (5917,'Remessa de mercadoria em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (5918,'Devolu��o de mercadoria recebida em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (5919,'Devolu��o simb�lica de mercadoria vendida ou utilizada em processo industrial, recebida anteriormente em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (5920,'Remessa de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (5921,'Devolu��o de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (5922,'Lan�amento efetuado a t�tulo de simples faturamento decorrente de venda para entrega futura\r');
INSERT INTO `cfop` VALUES (5923,'Remessa de mercadoria por conta e ordem de terceiros, em venda � ordem\r');
INSERT INTO `cfop` VALUES (5924,'Remessa para industrializa��o por conta e ordem do adquirente da mercadoria, quando esta n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (5925,'Retorno de mercadoria recebida para industrializa��o por conta e ordem do adquirente da mercadoria, quando aquela n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (5926,'Lan�amento efetuado a t�tulo de reclassifica��o de mercadoria decorrente de forma��o de kit ou de sua desagrega��o\r');
INSERT INTO `cfop` VALUES (5927,'Lan�amento efetuado a t�tulo de baixa de estoque decorrente de perda, roubo ou deteriora��o\r');
INSERT INTO `cfop` VALUES (5928,'Lan�amento efetuado a t�tulo de baixa de estoque decorrente do encerramento da atividade da empresa\r');
INSERT INTO `cfop` VALUES (5929,'Lan�amento efetuado em decorr�ncia de emiss�o de documento fiscal relativo a opera��o ou presta��o tamb�m registrada em equipamento Emissor de Cupom Fiscal - ECF\r');
INSERT INTO `cfop` VALUES (5931,'Lan�amento efetuado em decorr�ncia da responsabilidade de reten��o do imposto por substitui��o tribut�ria, atribu�da ao remetente ou alienante da mercadoria, pelo servi�o de transporte realizado por transportador aut�nomo ou por transportador n�o inscrito na unidade da Federa��o onde iniciado o servi�o\r');
INSERT INTO `cfop` VALUES (5932,'Presta��o de servi�o de transporte iniciada em unidade da Federa��o diversa daquela onde inscrito o prestador\r');
INSERT INTO `cfop` VALUES (5949,'Outra sa�da de mercadoria ou presta��o de servi�o n�o especificado\r');
INSERT INTO `cfop` VALUES (6101,'Venda de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (6102,'Venda de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (6103,'Venda de produ��o do estabelecimento, efetuada fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (6104,'Venda de mercadoria adquirida ou recebida de terceiros, efetuada fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (6105,'Venda de produ��o do estabelecimento que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (6106,'Venda de mercadoria adquirida ou recebida de terceiros, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (6107,'Venda de produ��o do estabelecimento, destinada a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (6108,'Venda de mercadoria adquirida ou recebida de terceiros, destinada a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (6109,'Venda de produ��o do estabelecimento, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (6110,'Venda de mercadoria adquirida ou recebida de terceiros, destinada � Zona Franca de Manaus ou �reas de Livre Com�rcio\r');
INSERT INTO `cfop` VALUES (6111,'Venda de produ��o do estabelecimento remetida anteriormente em consigna��o industrial\r');
INSERT INTO `cfop` VALUES (6112,'Venda de mercadoria adquirida ou recebida de Terceiros remetida anteriormente em consigna��o industrial\r');
INSERT INTO `cfop` VALUES (6113,'Venda de produ��o do estabelecimento remetida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (6114,'Venda de mercadoria adquirida ou recebida de terceiros remetida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (6115,'Venda de mercadoria adquirida ou recebida de terceiros, recebida anteriormente em consigna��o mercantil\r');
INSERT INTO `cfop` VALUES (6116,'Venda de produ��o do estabelecimento originada de encomenda para entrega futura\r');
INSERT INTO `cfop` VALUES (6117,'Venda de mercadoria adquirida ou recebida de terceiros, originada de encomenda para entrega futura\r');
INSERT INTO `cfop` VALUES (6118,'Venda de produ��o do estabelecimento entregue ao destinat�rio por conta e ordem do adquirente origin�rio, em venda � ordem\r');
INSERT INTO `cfop` VALUES (6119,'Venda de mercadoria adquirida ou recebida de terceiros entregue ao destinat�rio por conta e ordem do adquirente origin�rio, em venda � ordem\r');
INSERT INTO `cfop` VALUES (6120,'Venda de mercadoria adquirida ou recebida de terceiros entregue ao destinat�rio pelo vendedor remetente, em venda � ordem\r');
INSERT INTO `cfop` VALUES (6122,'Venda de produ��o do estabelecimento remetida para industrializa��o, por conta e ordem do adquirente, sem transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (6123,'Venda de mercadoria adquirida ou recebida de terceiros remetida para industrializa��o, por conta e ordem do adquirente, sem transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (6124,'Industrializa��o efetuada para outra empresa\r');
INSERT INTO `cfop` VALUES (6125,'Industrializa��o efetuada para outra empresa quando a mercadoria recebida para utiliza��o no processo de industrializa��o n�o transitar pelo estabelecimento adquirente da mercadoria\r');
INSERT INTO `cfop` VALUES (6151,'Transfer�ncia de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (6152,'Transfer�ncia de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (6153,'Transfer�ncia de energia el�trica\r');
INSERT INTO `cfop` VALUES (6155,'Transfer�ncia de produ��o do estabelecimento, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (6156,'Transfer�ncia de mercadoria adquirida ou recebida de terceiros, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (6201,'Devolu��o de compra para industrializa��o\r');
INSERT INTO `cfop` VALUES (6202,'Devolu��o de compra para comercializa��o\r');
INSERT INTO `cfop` VALUES (6205,'Anula��o de valor relativo a aquisi��o de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (6206,'Anula��o de valor relativo a aquisi��o de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (6207,'Anula��o de valor relativo � compra de energia el�trica\r');
INSERT INTO `cfop` VALUES (6208,'Devolu��o de mercadoria recebida em transfer�ncia para industrializa��o\r');
INSERT INTO `cfop` VALUES (6209,'Devolu��o de mercadoria recebida em transfer�ncia para comercializa��o\r');
INSERT INTO `cfop` VALUES (6210,'Devolu��o de compra para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (6251,'Venda de energia el�trica para distribui��o ou comercializa��o\r');
INSERT INTO `cfop` VALUES (6252,'Venda de energia el�trica para estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (6253,'Venda de energia el�trica para estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (6254,'Venda de energia el�trica para estabelecimento prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (6255,'Venda de energia el�trica para estabelecimento prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (6256,'Venda de energia el�trica para estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (6257,'Venda de energia el�trica para consumo por demanda contratada\r');
INSERT INTO `cfop` VALUES (6258,'Venda de energia el�trica a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (6301,'Presta��o de servi�o de comunica��o para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (6302,'Presta��o de servi�o de comunica��o a estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (6303,'Presta��o de servi�o de comunica��o a estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (6304,'Presta��o de servi�o de comunica��o a estabelecimento de prestador de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (6305,'Presta��o de servi�o de comunica��o a estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (6306,'Presta��o de servi�o de comunica��o a estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (6307,'Presta��o de servi�o de comunica��o a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (6351,'Presta��o de servi�o de transporte para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (6352,'Presta��o de servi�o de transporte a estabelecimento industrial\r');
INSERT INTO `cfop` VALUES (6353,'Presta��o de servi�o de transporte a estabelecimento comercial\r');
INSERT INTO `cfop` VALUES (6354,'Presta��o de servi�o de transporte a estabelecimento de prestador de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (6355,'Presta��o de servi�o de transporte a estabelecimento de geradora ou de distribuidora de energia el�trica\r');
INSERT INTO `cfop` VALUES (6356,'Presta��o de servi�o de transporte a estabelecimento de produtor rural\r');
INSERT INTO `cfop` VALUES (6357,'Presta��o de servi�o de transporte a n�o contribuinte\r');
INSERT INTO `cfop` VALUES (6401,'Venda de produ��o do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria, na condi��o de contribuinte substituto\r');
INSERT INTO `cfop` VALUES (6402,'Venda de produ��o do estabelecimento de produto sujeito ao regime de substitui��o tribut�ria, em opera��o entre contribuintes substitutos do mesmo produto\r');
INSERT INTO `cfop` VALUES (6403,'Venda de mercadoria adquirida ou recebida de terceiros em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria, na condi��o de contribuinte substituto\r');
INSERT INTO `cfop` VALUES (6404,'Venda de mercadoria sujeita ao regime de substitui��o tribut�ria, cujo imposto j� tenha sido retido anteriormente\r');
INSERT INTO `cfop` VALUES (6408,'Transfer�ncia de produ��o do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6409,'Transfer�ncia de mercadoria adquirida ou recebida de terceiros em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6410,'Devolu��o de compra para industrializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6411,'Devolu��o de compra para comercializa��o em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6412,'Devolu��o de bem do ativo imobilizado, em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6413,'Devolu��o de mercadoria destinada ao uso ou consumo, em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6414,'Remessa de produ��o do estabelecimento para venda fora do estabelecimento em opera��o com produto sujeito ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6415,'Remessa de mercadoria adquirida ou recebida de terceiros para venda fora do estabelecimento, em opera��o com mercadoria sujeita ao regime de substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6501,'Remessa de produ��o do estabelecimento, com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (6502,'Remessa de mercadoria adquirida ou recebida de terceiros, com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (6503,'Devolu��o de mercadoria recebida com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (6551,'Venda de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (6552,'Transfer�ncia de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (6553,'Devolu��o de compra de bem para o ativo imobilizado\r');
INSERT INTO `cfop` VALUES (6554,'Remessa de bem do ativo imobilizado para uso fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (6555,'Devolu��o de bem do ativo imobilizado de terceiro, recebido para uso no estabelecimento\r');
INSERT INTO `cfop` VALUES (6556,'Devolu��o de compra de material de uso ou consumo\r');
INSERT INTO `cfop` VALUES (6557,'Transfer�ncia de material de uso ou consumo\r');
INSERT INTO `cfop` VALUES (6603,'Ressarcimento de ICMS retido por substitui��o tribut�ria\r');
INSERT INTO `cfop` VALUES (6901,'Remessa para industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (6902,'Retorno de mercadoria utilizada na industrializa��o por encomenda\r');
INSERT INTO `cfop` VALUES (6903,'Retorno de mercadoria recebida para industrializa��o e n�o aplicada no referido processo\r');
INSERT INTO `cfop` VALUES (6904,'Remessa para venda fora do estabelecimento\r');
INSERT INTO `cfop` VALUES (6905,'Remessa para dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (6906,'Retorno de mercadoria depositada em dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (6907,'Retorno simb�lico de mercadoria depositada em dep�sito fechado ou armaz�m geral\r');
INSERT INTO `cfop` VALUES (6908,'Remessa de bem por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (6909,'Retorno de bem recebido por conta de contrato de comodato\r');
INSERT INTO `cfop` VALUES (6910,'Remessa em bonifica��o, doa��o ou brinde\r');
INSERT INTO `cfop` VALUES (6911,'Remessa de amostra gr�tis\r');
INSERT INTO `cfop` VALUES (6912,'Remessa de mercadoria ou bem para demonstra��o\r');
INSERT INTO `cfop` VALUES (6913,'Retorno de mercadoria ou bem recebido para demonstra��o\r');
INSERT INTO `cfop` VALUES (6914,'Remessa de mercadoria ou bem para exposi��o ou feira\r');
INSERT INTO `cfop` VALUES (6915,'Remessa de mercadoria ou bem para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (6916,'Retorno de mercadoria ou bem recebido para conserto ou reparo\r');
INSERT INTO `cfop` VALUES (6917,'Remessa de mercadoria em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (6918,'Devolu��o de mercadoria recebida em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (6919,'Devolu��o simb�lica de mercadoria vendida ou utilizada em processo industrial, recebida anteriormente em consigna��o mercantil ou industrial\r');
INSERT INTO `cfop` VALUES (6920,'Remessa de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (6921,'Devolu��o de vasilhame ou sacaria\r');
INSERT INTO `cfop` VALUES (6922,'Lan�amento efetuado a t�tulo de simples faturamento decorrente de venda para entrega futura\r');
INSERT INTO `cfop` VALUES (6923,'Remessa de mercadoria por conta e ordem de terceiros, em venda � ordem\r');
INSERT INTO `cfop` VALUES (6924,'Remessa para industrializa��o por conta e ordem do adquirente da mercadoria, quando esta n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (6925,'Retorno de mercadoria recebida para industrializa��o por conta e ordem do adquirente da mercadoria, quando aquela n�o transitar pelo estabelecimento do adquirente\r');
INSERT INTO `cfop` VALUES (6929,'Lan�amento efetuado em decorr�ncia de emiss�o de documento fiscal relativo a opera��o ou presta��o tamb�m registrada em equipamento Emissor de Cupom Fiscal - ECF\r');
INSERT INTO `cfop` VALUES (6931,'Lan�amento efetuado em decorr�ncia da responsabilidade de reten��o do imposto por substitui��o tribut�ria, atribu�da ao remetente ou alienante da mercadoria, pelo servi�o de transporte realizado por transportador aut�nomo ou por transportador n�o inscrito na unidade da Federa��o onde iniciado o servi�o\r');
INSERT INTO `cfop` VALUES (6932,'Presta��o de servi�o de transporte iniciada em unidade da Federa��o diversa daquela onde inscrito o prestador\r');
INSERT INTO `cfop` VALUES (6949,'Outra sa�da de mercadoria ou presta��o de servi�o n�o especificado\r');
INSERT INTO `cfop` VALUES (7101,'Venda de produ��o do estabelecimento\r');
INSERT INTO `cfop` VALUES (7102,'Venda de mercadoria adquirida ou recebida de terceiros\r');
INSERT INTO `cfop` VALUES (7105,'Venda de produ��o do estabelecimento, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (7106,'Venda de mercadoria adquirida ou recebida de terceiros, que n�o deva por ele transitar\r');
INSERT INTO `cfop` VALUES (7127,'Venda de produ��o do estabelecimento sob o regime de drawback\r');
INSERT INTO `cfop` VALUES (7201,'Devolu��o de compra para industrializa��o\r');
INSERT INTO `cfop` VALUES (7202,'Devolu��o de compra para comercializa��o\r');
INSERT INTO `cfop` VALUES (7205,'Anula��o de valor relativo � aquisi��o de servi�o de comunica��o\r');
INSERT INTO `cfop` VALUES (7206,'Anula��o de valor relativo a aquisi��o de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (7207,'Anula��o de valor relativo � compra de energia el�trica\r');
INSERT INTO `cfop` VALUES (7210,'Devolu��o de compra para utiliza��o na presta��o de servi�o\r');
INSERT INTO `cfop` VALUES (7211,'Devolu��o de compras para industrializa��o sob o regime de drawback\r');
INSERT INTO `cfop` VALUES (7251,'Venda de energia el�trica para o exterior\r');
INSERT INTO `cfop` VALUES (7301,'Presta��o de servi�o de comunica��o para execu��o de servi�o da mesma natureza\r');
INSERT INTO `cfop` VALUES (7358,'Presta��o de servi�o de transporte\r');
INSERT INTO `cfop` VALUES (7501,'Exporta��o de mercadorias recebidas com fim espec�fico de exporta��o\r');
INSERT INTO `cfop` VALUES (7551,'Venda de bem do ativo imobilizado\r');
INSERT INTO `cfop` VALUES (7553,'Devolu��o de compra de bem para o ativo imobilizado\r');
INSERT INTO `cfop` VALUES (7556,'Devolu��o de compra de material de uso ou consumo\r');
INSERT INTO `cfop` VALUES (7930,'Lan�amento efetuado a t�tulo de devolu��o de bem cuja entrada tenha ocorrido sob amparo de regime especial aduaneiro de admiss�o tempor�ria\r');
INSERT INTO `cfop` VALUES (7949,'Outra sa�da de mercadoria ou presta��o de servi�o n�o especificado\r');
/*!40000 ALTER TABLE `cfop` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cheque_ncomp
#

DROP TABLE IF EXISTS `cheque_ncomp`;
CREATE TABLE `cheque_ncomp` (
  `COD_NCOMP` int(11) NOT NULL auto_increment,
  `NUM_CHEQUE_NCOMP` int(11) default NULL,
  `DATA_CHEQUE_NCOMP` date default NULL,
  `VLR_CHEQUE_NCOMP` double(11,2) default NULL,
  `MES_ANO_NCOMP` varchar(7) default NULL,
  `HISTORICO_NCOMP` varchar(50) default NULL,
  PRIMARY KEY  (`COD_NCOMP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table cheque_ncomp
#

LOCK TABLES `cheque_ncomp` WRITE;
/*!40000 ALTER TABLE `cheque_ncomp` DISABLE KEYS */;
/*!40000 ALTER TABLE `cheque_ncomp` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cliente
#

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE `cliente` (
  `COD_CLIENTE` int(11) NOT NULL auto_increment COMMENT 'codigo do cliente - auto-incremento',
  `NOME_CLIENTE` varchar(50) default NULL,
  `CPF_CLIENTE` varchar(15) default NULL,
  `RG_CLIENTE` varchar(25) default NULL,
  `ORGAO_RG_CLIENTE` varchar(10) default NULL,
  `NASCIMENTO_CLIENTE` varchar(15) default NULL,
  `DESDE_CLIENTE` varchar(50) default NULL,
  `PROFISSAO_CLIENTE` varchar(40) default NULL,
  `EMPRESA_CLIENTE` varchar(50) default NULL,
  `FONE_EMPRESA` varchar(15) default NULL,
  `RENDA_CLIENTE` double(11,2) default NULL,
  `TIPO_CLIENTE` char(1) default NULL,
  `CNPJ_CLIENTE` varchar(20) default NULL,
  `REFERENCIA_CLIENTE` varchar(50) default NULL,
  `FONE_REFERENCIA_CLIENTE` varchar(10) default NULL,
  `EMAIL` varchar(100) default NULL,
  PRIMARY KEY  (`COD_CLIENTE`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COMMENT='tabela que armazena os dados dos clientes';

#
# Dumping data for table cliente
#

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;

INSERT INTO `cliente` VALUES (1,'Marco Antonio','031.043.210-35','6066985983','SSp','08/05/1992','01/01/2011','Engenheiro','S.A. Enguenharia','35982870',19000,'G','89.457.545/2831-45','4hnbvkn','30490053','marco.antonio.scholl@gmail.com');
INSERT INTO `cliente` VALUES (2'Jo�o paulo','12345','1456454','ssp','','','Func.  Publica',NULL,'0312548',1500,'H','','1563','4434','teste');
INSERT INTO `cliente` VALUES (3,'Felipe Elemar Scholl','013.681.450-60','00000000000',NULL,'31/10/1986','25/09/2005','Auxiliar Administrativo','Prefeitura de Campo Bom','(51)3592-1113',1500,NULL,'03.158.748/5488-21',NULL,NULL,'felipe@campobom.rs.gov.br');
INSERT INTO `cliente` VALUES (4,'Pedro De Souza','123456','987654321',NULL,'',NULL,'Faxineira','Casa','3258748',40000,'J','',NULL,NULL,'faxi@neira.com');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cliente_endereco
#

DROP TABLE IF EXISTS `cliente_endereco`;
CREATE TABLE `cliente_endereco` (
  `COD_ENDERECO` int(11) NOT NULL auto_increment,
  `COD_CLIENTE` int(11) default NULL COMMENT 'codigo do cliente - auto-incremento',
  `LOGRADOURO_ENDERECO` varchar(50) default NULL,
  `COMPLEMENTO_ENDERECO` varchar(50) default NULL,
  `CEP_ENDERECO` varchar(8) default NULL,
  `BAIRRO_ENDERECO` varchar(50) default NULL,
  `CIDADE_ENDERECO` varchar(50) default NULL,
  `UF_ENDERECO` char(2) default NULL,
  PRIMARY KEY  (`COD_ENDERECO`),
  KEY `FK_CLIENTE_ENDERECO` (`COD_CLIENTE`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

#
# Dumping data for table cliente_endereco
#

LOCK TABLES `cliente_endereco` WRITE;
/*!40000 ALTER TABLE `cliente_endereco` DISABLE KEYS */;
INSERT INTO `cliente_endereco` VALUES (1,1,'RUA MARIA',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cliente_endereco` VALUES (2,1,'RUA TAL',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cliente_endereco` VALUES (3,2,'RUA JOAO',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cliente_endereco` VALUES (4,2,'RUA JOAO DA SILVA',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cliente_endereco` VALUES (5,2,'RUA SILVA',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cliente_endereco` VALUES (6,8,'Presidente costa e silva','134','93700000','Celeste','Campo Bom','RS');
INSERT INTO `cliente_endereco` VALUES (7,9,'Rua Presidente Costa e Silva','Casa','93700000','Celeste','Campo Bom','RS');
/*!40000 ALTER TABLE `cliente_endereco` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cliente_telefone
#

DROP TABLE IF EXISTS `cliente_telefone`;
CREATE TABLE `cliente_telefone` (
  `COD_TELEFONE` int(11) NOT NULL auto_increment,
  `COD_CLIENTE` int(11) default NULL COMMENT 'codigo do cliente - auto-incremento',
  `NUMERO_TELEFONE` varchar(10) default NULL,
  `TIPO_TELEFONE` char(1) default NULL,
  PRIMARY KEY  (`COD_TELEFONE`),
  KEY `FK_CLIENTE_TELEFONE` (`COD_CLIENTE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='telefones dos clientes';

#
# Dumping data for table cliente_telefone
#

LOCK TABLES `cliente_telefone` WRITE;
/*!40000 ALTER TABLE `cliente_telefone` DISABLE KEYS */;
/*!40000 ALTER TABLE `cliente_telefone` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cobranca
#

DROP TABLE IF EXISTS `cobranca`;
CREATE TABLE `cobranca` (
  `COD_COBRANCA` int(11) NOT NULL auto_increment,
  `COD_CLIENTE` int(11) default NULL COMMENT 'codigo do cliente - auto-incremento',
  `ASSUNTO_COBRANCA` varchar(50) default NULL,
  `TEXTO_COBRANCA` text,
  `ENVIO1` date default NULL,
  `ENVIO2` date default NULL,
  `ENVIO3` date default NULL,
  `ENVIO4` date default NULL,
  `ENVIO5` date default NULL,
  `NUM_PROCESSO` varchar(30) default NULL,
  `DATA_PROCESSO` date default NULL,
  `ADVOGADO_PROCESSO` varchar(50) default NULL,
  PRIMARY KEY  (`COD_COBRANCA`),
  KEY `FK_CLIENTE_COBRANCA` (`COD_CLIENTE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table cobranca
#

LOCK TABLES `cobranca` WRITE;
/*!40000 ALTER TABLE `cobranca` DISABLE KEYS */;
/*!40000 ALTER TABLE `cobranca` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table conciliacao
#

DROP TABLE IF EXISTS `conciliacao`;
CREATE TABLE `conciliacao` (
  `COD_CONCILIACAO` int(11) NOT NULL auto_increment,
  `NUM_CHEQUE_CONCILIACAO` int(11) default NULL,
  `DATA_CHEQUE_CONCILIACAO` date default NULL,
  `VLR_CHEQUE_CONCILIACAO` double(11,2) default NULL,
  `MES_ANO_CONCILIACAO` varchar(7) default NULL,
  `HISTORICO_CONCILIACAO` varchar(50) default NULL,
  PRIMARY KEY  (`COD_CONCILIACAO`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

#
# Dumping data for table conciliacao
#

LOCK TABLES `conciliacao` WRITE;
/*!40000 ALTER TABLE `conciliacao` DISABLE KEYS */;
INSERT INTO `conciliacao` VALUES (1,150250,'2008-10-15',100,'10/2008','ENERGIA ELETRICA - ENERGIAS LTDA');
INSERT INTO `conciliacao` VALUES (2,150251,'2008-10-14',500,'10/2008','AGUA - AGUAS LTDA');
INSERT INTO `conciliacao` VALUES (3,150252,'2008-04-04',1000,'04/2008','TELEFONE - TELEFONES LTDA');
/*!40000 ALTER TABLE `conciliacao` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table correios_ceps
#

DROP TABLE IF EXISTS `correios_ceps`;
CREATE TABLE `correios_ceps` (
  `Id` int(6) unsigned NOT NULL auto_increment,
  `logradouro` varchar(72) default NULL,
  `complemento` varchar(72) default NULL,
  `cep` varchar(9) default NULL,
  `bairro` varchar(72) default NULL,
  `cidade` varchar(72) default NULL,
  `uf` char(2) default NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=699309 DEFAULT CHARSET=latin1;



#
# Source for table cot_cab
#

DROP TABLE IF EXISTS `cot_cab`;
CREATE TABLE `cot_cab` (
  `COD_COT_CAB` int(11) NOT NULL auto_increment,
  `DATA_COT_CAT` date default NULL,
  `FORN1` int(11) default NULL,
  `FORN2` int(11) default NULL,
  `FORN3` int(11) default NULL,
  `FORN4` int(11) default NULL,
  `FORN5` int(11) default NULL,
  `CONDICOES1` varchar(30) default NULL,
  `CONDICOES2` varchar(30) default NULL,
  `CONDICOES3` varchar(30) default NULL,
  `CONDICOES4` varchar(30) default NULL,
  `CONDICOES5` varchar(30) default NULL,
  `DESCONTO1` double(11,2) default NULL,
  `DESCONTO2` double(11,2) default NULL,
  `DESCONTO3` double(11,2) default NULL,
  `DESCONTO4` double(11,2) default NULL,
  `DESCONTO5` double(11,2) default NULL,
  `ENTREGA1` varchar(30) default NULL,
  `ENTREGA2` varchar(30) default NULL,
  `ENTREGA3` varchar(30) default NULL,
  `ENTREGA4` varchar(30) default NULL,
  `ENTREGA5` varchar(30) default NULL,
  `TOTAL1` double(11,2) default NULL,
  `TOTAL2` double(11,2) default NULL,
  `TOTAL3` double(11,2) default NULL,
  `TOTAL4` double(11,2) default NULL,
  `TOTAL5` double(11,2) default NULL,
  PRIMARY KEY  (`COD_COT_CAB`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Dumping data for table cot_cab
#

LOCK TABLES `cot_cab` WRITE;
/*!40000 ALTER TABLE `cot_cab` DISABLE KEYS */;
INSERT INTO `cot_cab` VALUES (5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cot_cab` VALUES (6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cot_cab` VALUES (7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cot_cab` VALUES (8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cot_cab` VALUES (9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `cot_cab` VALUES (10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `cot_cab` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table cot_det
#

DROP TABLE IF EXISTS `cot_det`;
CREATE TABLE `cot_det` (
  `COD_COT_CAB` int(11) NOT NULL,
  `COD_PRODUTO` varchar(13) NOT NULL,
  `COD_REQ_CAB` int(11) NOT NULL,
  `QTDE_COT_DET` int(11) default NULL,
  `UNIT1` double(11,2) default NULL,
  `UNIT2` double(11,2) default NULL,
  `UNIT3` double(11,2) default NULL,
  `UNIT4` double(11,2) default NULL,
  `UNIT5` double(11,2) default NULL,
  `TOTAL1` double(11,2) default NULL,
  `TOTAL2` double(11,2) default NULL,
  `TOTAL3` double(11,2) default NULL,
  `TOTAL4` double(11,2) default NULL,
  `TOTAL5` double(11,2) default NULL,
  PRIMARY KEY  (`COD_COT_CAB`,`COD_PRODUTO`,`COD_REQ_CAB`),
  KEY `FK_REQ_DET_COT_DET` (`COD_PRODUTO`,`COD_REQ_CAB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table cot_det
#

LOCK TABLES `cot_det` WRITE;
/*!40000 ALTER TABLE `cot_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `cot_det` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table departamento
#

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE `departamento` (
  `COD_DEPARTAMENTO` int(11) NOT NULL auto_increment,
  `NOME_DEPARTAMENTO` varchar(50) default NULL,
  PRIMARY KEY  (`COD_DEPARTAMENTO`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

#
# Dumping data for table departamento
#

LOCK TABLES `departamento` WRITE;
/*!40000 ALTER TABLE `departamento` DISABLE KEYS */;
INSERT INTO `departamento` VALUES (1,'VENDA');
INSERT INTO `departamento` VALUES (2,'INFORMATICA');
INSERT INTO `departamento` VALUES (3,'ESTOQUE');
INSERT INTO `departamento` VALUES (4,'Compras');
/*!40000 ALTER TABLE `departamento` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table fechamento
#

DROP TABLE IF EXISTS `fechamento`;
CREATE TABLE `fechamento` (
  `COD_FECHAMENTO` int(11) NOT NULL auto_increment,
  `MES_ANO_FECHAMENTO` varchar(7) default NULL,
  `VLR_SALDO_ANTERIOR` double(11,2) default NULL,
  `VLR_RECEBIMENTOS` double(11,2) default NULL,
  `VLR_PAGAMENTOS` double(11,2) default NULL,
  `VLR_CHEQUE_NCOMP` double(11,2) default NULL,
  `VLR_SALDO_CONTA` double(11,2) default NULL,
  `VLR_SALDO_REAL` double(11,2) default NULL,
  PRIMARY KEY  (`COD_FECHAMENTO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table fechamento
#

LOCK TABLES `fechamento` WRITE;
/*!40000 ALTER TABLE `fechamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `fechamento` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table fornecedor
#

DROP TABLE IF EXISTS `fornecedor`;
CREATE TABLE `fornecedor` (
  `COD_FORNECEDOR` int(11) NOT NULL auto_increment,
  `NOME_FORNECEDOR` varchar(50) default NULL,
  `CPF_FORNECEDOR` varchar(12) default NULL,
  `RG_FORNECEDOR` varchar(25) default NULL,
  `ORGAO_RG_FORNECEDOR` varchar(10) default NULL,
  `CNPJ_FORNECEDOR` varchar(14) default NULL,
  `TIPO_FORNECEDOR` char(1) default NULL,
  `ENDERECO_FORNECEDOR` varchar(100) default NULL,
  `BAIRRO_FORNECEDOR` varchar(50) default NULL,
  `CIDADE_FORNECEDOR` varchar(50) default NULL,
  `UF_FORNECEDOR` char(2) default NULL,
  `CEP_FORNECEDOR` varchar(9) default NULL,
  `EMAIL_FORNECEDOR` varchar(100) default NULL,
  `SITE_FORNECEDOR` varchar(100) default NULL,
  `FONE_FORNECEDOR` varchar(10) default NULL,
  `CELULAR_FORNECEDOR` varchar(10) default NULL,
  `FAX_FORNECEDOR` varchar(10) default NULL,
  `CONTATO_FORNECEDOR` varchar(50) default NULL,
  PRIMARY KEY  (`COD_FORNECEDOR`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

#
# Dumping data for table fornecedor
#

LOCK TABLES `fornecedor` WRITE;
/*!40000 ALTER TABLE `fornecedor` DISABLE KEYS */;
INSERT INTO `fornecedor` VALUES (1,'CASAS BAHIA',NULL,NULL,NULL,'121321321','J','RUA TAL','CENTRO','SAO PAULO','SP','60500454','BAHIA@GMAIL.COM','CASASBAHIA.COM.BR','5135982870','5198584863',NULL,'JOAO PAULO');
INSERT INTO `fornecedor` VALUES (2,'JOAO PAULO','12345678910','903213','SSP-CE',NULL,'F','RUA JOAO PAULO','CENTRO','FORTALEZA','CE','60123456','JOAO@GMAIL.COM','NAO TEM','8532145879','8532145674',NULL,'JOAO PAULO');
INSERT INTO `fornecedor` VALUES (3,'MERCADINHO GG','           ',NULL,NULL,'1231321231','J',NULL,NULL,NULL,NULL,'6075000',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `fornecedor` VALUES (4,'JOAO GALDINO ME','           ',NULL,NULL,'121321','J','RUA ABELHAS','SANTA QUIT�RIA','RIO BRANCO','AC','69914370','GALDINO@GMAIL','NAO TEM','8432125448',NULL,NULL,NULL);
INSERT INTO `fornecedor` VALUES (5,'ENERGIAS LTDA',NULL,NULL,NULL,NULL,'F','RUA A�UCENAS','CAP�O DO ANGICO','ALEGRETE','RS','97547010',NULL,NULL,'0000000000','5135982870',NULL,NULL);
INSERT INTO `fornecedor` VALUES (6,'AGUAS LTDA',NULL,NULL,NULL,NULL,'J',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `fornecedor` VALUES (7,'TELEFONES LTDA',NULL,NULL,NULL,NULL,'J',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `fornecedor` VALUES (8,'Pedro',NULL,'0000000000','spc-rs','0001521','F','Presidente Isabel','Princesa Isabel','Dois Irmaos','rs','121551','betorebeca@hotmail.com','Nao tem','81418848','8888','888','Pedroo');
INSERT INTO `fornecedor` VALUES (10,'Scholl','03104322007','11111111','RS','11111111111','F','Presidente costa e Silva','Celeste','Campo Bom','RS','93700000','viny_scholl@hotmail.com','www.devils-hackers.50webs.com','30490053',NULL,NULL,'Scholl');
INSERT INTO `fornecedor` VALUES (11,'aysfyahsvcas','00000000000','vhjdfjkvdkflv','nvd','2131234122','F','jkbc','asm,c','aksc','ak','93700000','ajsckca','skcvlk','kslnvlks','snklsk','skvnls','s�lv�lsdv');
INSERT INTO `fornecedor` VALUES (12,'dghgdfhfdh22222222',NULL,'wdsds','sx','swdsd212121','F','sascasc','ascasc','sca','as','93700000','asdasd','dsadasdx','5135982870','5198584863','dasd','sadxsdcasc');
INSERT INTO `fornecedor` VALUES (15,'dfsdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `fornecedor` VALUES (16,'Alberto',NULL,NULL,NULL,'454554','J','AVENIDA DOM ANT�NIO BRAND�O, 333','FAROL','MACEI�',NULL,NULL,'Nao','Nao','5188888888','5188888888','888888','dhbdsjh');
INSERT INTO `fornecedor` VALUES (17,'Padaria Scholl','03104322007','1212121212',NULL,NULL,'F','<COMPLETAR>','<COMPLETAR>','CAMPO BOM',NULL,NULL,'viny_scholl@hotmail.com','NAO','5100000000','0000000000','00000000','nao');
INSERT INTO `fornecedor` VALUES (18,'P',NULL,NULL,NULL,'45444444','J','RUA ALFEU BICCA DE MEDEIROS','RESTINGA','ALEGRETE','RS','97542030','N','N','0000000000','0000000000','N','N');
/*!40000 ALTER TABLE `fornecedor` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table funcionario
#

DROP TABLE IF EXISTS `funcionario`;
CREATE TABLE `funcionario` (
  `COD_FUNCIONARIO` int(11) NOT NULL auto_increment,
  `COD_DEPARTAMENTO` int(11) default NULL,
  `NOME_FUNCIONARIO` varchar(50) default NULL,
  `FUNCAO_FUNCIONARIO` varchar(50) default NULL,
  `LOGIN_FUNCIONARIO` varchar(50) default NULL,
  `SENHA_FUNCIONARIO` varchar(50) default NULL,
  `ADMISSAO_FUNCIONARIO` varchar(15) default NULL,
  `ACESSO_TOTAL` char(1) default NULL,
  PRIMARY KEY  (`COD_FUNCIONARIO`),
  KEY `FK_DEPARTAMENTO_FUNCIONARIO` (`COD_DEPARTAMENTO`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

#
# Dumping data for table funcionario
#

LOCK TABLES `funcionario` WRITE;
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` VALUES (1,1,'Marco Antonio Scholl','Gerente','marco','9YiNC7WNYREH4R98vEHJeg==','11/11/1111','1');
INSERT INTO `funcionario` VALUES (2,4,'Marcos','faxineiro','marcos','xeNTkSHElE8rvgl7Ql7ndA==','11/11/1111','1');
INSERT INTO `funcionario` VALUES (3,1,'Carol','Caixa','carol','qaAZgBCmBz25ZDT2zF8iqA==','15/02/2011','0');
INSERT INTO `funcionario` VALUES (4,1,'Preta','Faxineira','preta','TQFRviygpzjCluKWmgZJjA==','15/02/2011','0');
INSERT INTO `funcionario` VALUES (5,2,'Marcos Vinicius','Manuten��o de Hardware','viny','SiUl5bPU2KLfmUR3XlA4Cg==','31/10/2009','0');
INSERT INTO `funcionario` VALUES (6,1,'Beto','Dono','beto','qrci2iG+etB6O3Lu3kqemg==','11/11/1111','1');
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table movimento
#

DROP TABLE IF EXISTS `movimento`;
CREATE TABLE `movimento` (
  `COD_MOVIMENTO` int(11) NOT NULL auto_increment,
  `COD_PLANO_CONTA` int(4) default NULL,
  `MES_ANO_MOVIMENTO` varchar(7) default NULL,
  `NUM_CHEQUE_MOVIMENTO` int(11) default NULL,
  `NUM_DOCUMENTO_MOVIMENTO` varchar(20) default NULL,
  `DATA_CHEQUE_MOVIMENTO` date default NULL,
  `DATA_LANCAMENTO_MOVIMENTO` date default NULL,
  `HISTORICO_MOVIMENTO` varchar(50) default NULL,
  `VLR_DOCUMENTO_MOVIMENTO` double(11,2) default NULL,
  `COD_BANCO` int(11) default NULL,
  PRIMARY KEY  (`COD_MOVIMENTO`),
  KEY `FK_PLANO_CONTA_MOVIMENTO` (`COD_PLANO_CONTA`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

#
# Dumping data for table movimento
#

LOCK TABLES `movimento` WRITE;
/*!40000 ALTER TABLE `movimento` DISABLE KEYS */;
INSERT INTO `movimento` VALUES (1,1,'10/2008',150250,'RECIBO 01','2008-10-15','2008-10-15','ENERGIA ELETRICA - ENERGIAS LTDA',100,1);
INSERT INTO `movimento` VALUES (2,2,'10/2008',150251,'123456','2008-10-14','2008-10-14','AGUA - AGUAS LTDA',500,1);
INSERT INTO `movimento` VALUES (3,3,'04/2008',150252,'789456','2008-04-04','2008-04-04','TELEFONE - TELEFONES LTDA',1000,1);
/*!40000 ALTER TABLE `movimento` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table nfe_cab
#

DROP TABLE IF EXISTS `nfe_cab`;
CREATE TABLE `nfe_cab` (
  `NUMERO_NFE_CAB` int(11) NOT NULL,
  `COD_CFOP` int(11) default NULL,
  `COD_FORNECEDOR` int(11) default NULL,
  `EMISSAO_NFE_CAB` date default NULL,
  `ENTRADA_NFE_CAB` date default NULL,
  `TOTAL_NFE_CAB` double(11,2) default NULL,
  PRIMARY KEY  (`NUMERO_NFE_CAB`),
  KEY `FK_CFOP_NFE_CAB` (`COD_CFOP`),
  KEY `FK_FORNECEDOR_NFE_CAB` (`COD_FORNECEDOR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table nfe_cab
#

LOCK TABLES `nfe_cab` WRITE;
/*!40000 ALTER TABLE `nfe_cab` DISABLE KEYS */;
INSERT INTO `nfe_cab` VALUES (1,1111,NULL,NULL,NULL,500);
INSERT INTO `nfe_cab` VALUES (2,1111,NULL,NULL,NULL,500);
/*!40000 ALTER TABLE `nfe_cab` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table nfe_det
#

DROP TABLE IF EXISTS `nfe_det`;
CREATE TABLE `nfe_det` (
  `COD_PRODUTO` varchar(13) NOT NULL,
  `NUMERO_NFE_CAB` int(11) NOT NULL,
  `QTDE_NFE_DET` int(11) default NULL,
  `VLR_UNIT_NFE_DET` double(11,2) default NULL,
  `VLR_TOTAL_NFE_DET` double(11,2) default NULL,
  PRIMARY KEY  (`COD_PRODUTO`,`NUMERO_NFE_CAB`),
  KEY `FK_NFE_CAB_NFE_DET` (`NUMERO_NFE_CAB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table nfe_det
#

LOCK TABLES `nfe_det` WRITE;
/*!40000 ALTER TABLE `nfe_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `nfe_det` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table nivel_acesso
#

DROP TABLE IF EXISTS `nivel_acesso`;
CREATE TABLE `nivel_acesso` (
  `COD_FUNC` int(11) default NULL,
  `NOME_MODULO` varchar(50) default NULL,
  `CODIGO` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`CODIGO`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

#
# Dumping data for table nivel_acesso
#

LOCK TABLES `nivel_acesso` WRITE;
/*!40000 ALTER TABLE `nivel_acesso` DISABLE KEYS */;
INSERT INTO `nivel_acesso` VALUES (1,'Clientes',5);
INSERT INTO `nivel_acesso` VALUES (4,'Clientes',6);
INSERT INTO `nivel_acesso` VALUES (4,'Contas Banc�rias',7);
INSERT INTO `nivel_acesso` VALUES (4,'Fornecedores',9);
INSERT INTO `nivel_acesso` VALUES (4,'Sistema de Seguran�a',10);
INSERT INTO `nivel_acesso` VALUES (4,'Utilit�rios',11);
INSERT INTO `nivel_acesso` VALUES (NULL,NULL,12);
INSERT INTO `nivel_acesso` VALUES (5,'Produtos',13);
INSERT INTO `nivel_acesso` VALUES (5,'Funcion�rios',14);
INSERT INTO `nivel_acesso` VALUES (5,'Conte�do',15);
INSERT INTO `nivel_acesso` VALUES (5,'Plano de Contas',16);
INSERT INTO `nivel_acesso` VALUES (5,'Calend�rio',17);
INSERT INTO `nivel_acesso` VALUES (5,'Calculadora',18);
INSERT INTO `nivel_acesso` VALUES (5,'Departamento',19);
INSERT INTO `nivel_acesso` VALUES (5,'Sistema de Seguran�a',20);
INSERT INTO `nivel_acesso` VALUES (5,'Fornecedores',21);
INSERT INTO `nivel_acesso` VALUES (5,'Contas Banc�rias',22);
INSERT INTO `nivel_acesso` VALUES (5,'Clientes',23);
INSERT INTO `nivel_acesso` VALUES (5,'Or�amentos',24);
INSERT INTO `nivel_acesso` VALUES (5,'Sair',25);
INSERT INTO `nivel_acesso` VALUES (5,'Sobre o Sistema',26);
INSERT INTO `nivel_acesso` VALUES (5,'Cart�es',27);
INSERT INTO `nivel_acesso` VALUES (5,'Controle de Estoque',28);
INSERT INTO `nivel_acesso` VALUES (5,'Tesouraria e Banco',29);
INSERT INTO `nivel_acesso` VALUES (5,'Contas a Pagar',30);
INSERT INTO `nivel_acesso` VALUES (5,'Contas a Receber',31);
INSERT INTO `nivel_acesso` VALUES (5,'Vendas',32);
INSERT INTO `nivel_acesso` VALUES (5,'Unidades',33);
INSERT INTO `nivel_acesso` VALUES (5,'Compras',34);
INSERT INTO `nivel_acesso` VALUES (5,'Tipo Pgto/Rcbto',35);
/*!40000 ALTER TABLE `nivel_acesso` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table orc_cab
#

DROP TABLE IF EXISTS `orc_cab`;
CREATE TABLE `orc_cab` (
  `COD_ORC_CAB` int(11) NOT NULL auto_increment,
  `COD_CLIENTE` int(11) default NULL COMMENT 'codigo do cliente - auto-incremento',
  `COD_FUNCIONARIO` int(11) default NULL,
  `DATA_ORC_CAB` varchar(12) default NULL,
  `VLR_ORC_CAB` double(11,2) default NULL,
  PRIMARY KEY  (`COD_ORC_CAB`),
  KEY `FK_CLIENTE_ORC_CAB` (`COD_CLIENTE`),
  KEY `FK_FUNCIONARIO_ORC_CAB` (`COD_FUNCIONARIO`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

#
# Dumping data for table orc_cab
#

LOCK TABLES `orc_cab` WRITE;
/*!40000 ALTER TABLE `orc_cab` DISABLE KEYS */;
INSERT INTO `orc_cab` VALUES (3,8,2,'20/11/2010',35);
INSERT INTO `orc_cab` VALUES (4,8,1,'11/11/1111',NULL);
INSERT INTO `orc_cab` VALUES (5,8,2,'22/22/2222',NULL);
INSERT INTO `orc_cab` VALUES (7,8,2,'22/22/2222',456.4);
INSERT INTO `orc_cab` VALUES (8,8,2,'08/05/2011',NULL);
INSERT INTO `orc_cab` VALUES (9,8,2,'08/05/2011',2395.8);
INSERT INTO `orc_cab` VALUES (10,8,1,'11/11/1111',NULL);
INSERT INTO `orc_cab` VALUES (11,8,1,'11/11/1111',NULL);
INSERT INTO `orc_cab` VALUES (12,8,1,'11/11/1111',85);
INSERT INTO `orc_cab` VALUES (13,8,1,'11/11/1111',NULL);
INSERT INTO `orc_cab` VALUES (14,8,1,'11/11/1111',NULL);
INSERT INTO `orc_cab` VALUES (15,8,1,'11/11/1111',NULL);
INSERT INTO `orc_cab` VALUES (16,11,1,'11/11/1111',6720);
INSERT INTO `orc_cab` VALUES (17,1,1,'  /  /    ',450);
INSERT INTO `orc_cab` VALUES (18,8,1,'11/11/1111',165);
/*!40000 ALTER TABLE `orc_cab` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table orc_det
#

DROP TABLE IF EXISTS `orc_det`;
CREATE TABLE `orc_det` (
  `COD_ORC_CAB` int(11) NOT NULL,
  `COD_PRODUTO` varchar(13) NOT NULL,
  `QTDE_ORC_DET` int(11) default NULL,
  `VLR_UNIT_ORC_DET` double(11,2) default NULL,
  `VLR_TOTAL_ORC_DET` double(11,2) default NULL,
  PRIMARY KEY  (`COD_ORC_CAB`,`COD_PRODUTO`),
  KEY `FK_PRODUTO_ORC_DET` (`COD_PRODUTO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table orc_det
#

LOCK TABLES `orc_det` WRITE;
/*!40000 ALTER TABLE `orc_det` DISABLE KEYS */;
INSERT INTO `orc_det` VALUES (3,'1010',10,3.5,35);
INSERT INTO `orc_det` VALUES (7,'1',100,0.5,50);
INSERT INTO `orc_det` VALUES (7,'1010',10,3.5,35);
INSERT INTO `orc_det` VALUES (7,'1012',90,3,270);
INSERT INTO `orc_det` VALUES (7,'1014',16,2.9,46.4);
INSERT INTO `orc_det` VALUES (7,'111111',11,5,55);
INSERT INTO `orc_det` VALUES (9,'1010',10,3.5,35);
INSERT INTO `orc_det` VALUES (9,'1014',2,2.9,5.8);
INSERT INTO `orc_det` VALUES (9,'111111',5,5,25);
INSERT INTO `orc_det` VALUES (9,'sasas',10,233,2330);
INSERT INTO `orc_det` VALUES (12,'1010',10,3.5,35);
INSERT INTO `orc_det` VALUES (12,'111111',10,5,50);
INSERT INTO `orc_det` VALUES (16,'11111111',12,560,6720);
INSERT INTO `orc_det` VALUES (17,'111111',50,5,250);
INSERT INTO `orc_det` VALUES (17,'2',100,2,200);
INSERT INTO `orc_det` VALUES (18,'1012',5,3,15);
INSERT INTO `orc_det` VALUES (18,'111111111',1,150,150);
/*!40000 ALTER TABLE `orc_det` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table pagamento
#

DROP TABLE IF EXISTS `pagamento`;
CREATE TABLE `pagamento` (
  `COD_PAGAMENTO` int(11) NOT NULL auto_increment,
  `COD_PLANO_CONTA` int(4) default NULL,
  `COD_TIPO_PGTO` int(11) default NULL,
  `COD_BANCO` int(11) default NULL,
  `COD_FORNECEDOR` int(11) default NULL,
  `NUM_DOC_PAGAMENTO` varchar(20) default NULL,
  `VLR_TOTAL_PAGAMENTO` double(11,2) default NULL,
  `VLR_JURO_PAGAMENTO` double(11,2) default NULL,
  `VLR_MULTA_PAGAMENTO` double(11,2) default NULL,
  `VLR_DESCONTO_PAGAMENTO` double(11,2) default NULL,
  `VLR_PAGO_PAGAMENTO` double(11,2) default NULL,
  `NUM_CHEQUE_PAGAMENTO` int(11) default NULL,
  `NOMINAL_PAGAMENTO` varchar(50) default NULL,
  `EMISSAO_PAGAMENTO` date default NULL,
  `LANCAMENTO_PAGAMENTO` date default NULL,
  `VENCIMENTO_PAGAMENTO` date default NULL,
  `DATA_PAGAMENTO` date default NULL,
  `DATA_CHEQUE_PAGAMENTO` date default NULL,
  PRIMARY KEY  (`COD_PAGAMENTO`),
  KEY `FK_BANCO_PAGAMENTO` (`COD_BANCO`),
  KEY `FK_FORNECEDOR_PAGAMENTO` (`COD_FORNECEDOR`),
  KEY `FK_PLANO_CONTA_PAGAMENTO` (`COD_PLANO_CONTA`),
  KEY `FK_TIPO_PGTO_PAGAMENTO` (`COD_TIPO_PGTO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table pagamento
#

LOCK TABLES `pagamento` WRITE;
/*!40000 ALTER TABLE `pagamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagamento` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table pedido_cab
#

DROP TABLE IF EXISTS `pedido_cab`;
CREATE TABLE `pedido_cab` (
  `COD_PEDIDO_CAB` int(11) NOT NULL auto_increment,
  `COD_COT_CAB` int(11) default NULL,
  `COD_FORNECEDOR` int(11) default NULL,
  `DATA_PEDIDO_CAB` date default NULL,
  `ENDERECO_ENTREGA` varchar(50) default NULL,
  `ENDERECO_COBRANCA` varchar(50) default NULL,
  `VLR_PEDIDO_CAB` double(11,2) default NULL,
  `DESCONTO_PEDIDO_CAB` double(11,2) default NULL,
  `TOTAL_PEDIDO_CAB` double(11,2) default NULL,
  PRIMARY KEY  (`COD_PEDIDO_CAB`),
  KEY `FK_COT_CAB_PEDIDO_CAB` (`COD_COT_CAB`),
  KEY `FK_FORNECEDOR_PEDIDO_CAB` (`COD_FORNECEDOR`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table pedido_cab
#

LOCK TABLES `pedido_cab` WRITE;
/*!40000 ALTER TABLE `pedido_cab` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido_cab` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table pedido_det
#

DROP TABLE IF EXISTS `pedido_det`;
CREATE TABLE `pedido_det` (
  `COD_PEDIDO_CAB` int(11) NOT NULL,
  `COD_COT_CAB` int(11) NOT NULL,
  `COD_PRODUTO` varchar(13) NOT NULL,
  `COD_REQ_CAB` int(11) NOT NULL,
  `QTDE_PEDIDO_DET` int(11) default NULL,
  `VLR_UNIT_PEDIDO_DET` double(11,2) default NULL,
  `VLR_TOTAL_PEDIDO_DET` double(11,2) default NULL,
  PRIMARY KEY  (`COD_PEDIDO_CAB`,`COD_COT_CAB`,`COD_PRODUTO`,`COD_REQ_CAB`),
  KEY `FK_COT_DET_PEDIDO_DET` (`COD_COT_CAB`,`COD_PRODUTO`,`COD_REQ_CAB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table pedido_det
#

LOCK TABLES `pedido_det` WRITE;
/*!40000 ALTER TABLE `pedido_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido_det` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table plano_conta
#

DROP TABLE IF EXISTS `plano_conta`;
CREATE TABLE `plano_conta` (
  `COD_PLANO_CONTA` int(4) NOT NULL auto_increment,
  `DESCRICAO_PLANO_CONTA` varchar(20) default NULL,
  PRIMARY KEY  (`COD_PLANO_CONTA`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Dumping data for table plano_conta
#

LOCK TABLES `plano_conta` WRITE;
/*!40000 ALTER TABLE `plano_conta` DISABLE KEYS */;
INSERT INTO `plano_conta` VALUES (1,'ENERGIA ELETRICA');
INSERT INTO `plano_conta` VALUES (2,'AGUA');
INSERT INTO `plano_conta` VALUES (3,'TELEFONE');
INSERT INTO `plano_conta` VALUES (4,'VIGILANCIA');
INSERT INTO `plano_conta` VALUES (5,'Internet');
/*!40000 ALTER TABLE `plano_conta` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table produto
#

DROP TABLE IF EXISTS `produto`;
CREATE TABLE `produto` (
  `COD_PRODUTO` varchar(13) NOT NULL,
  `COD_UNIDADE` int(11) default NULL,
  `COD_FORNECEDOR` int(11) default NULL,
  `DESCRICAO_PRODUTO` varchar(50) default NULL,
  `VLR_COMPRA_PRODUTO` double(11,2) default NULL,
  `VLR_VENDA_PRODUTO` double(11,2) default NULL,
  `ESTOQUE_PRODUTO` int(11) default NULL,
  `CRITICO_PRODUTO` int(11) default NULL,
  PRIMARY KEY  (`COD_PRODUTO`),
  KEY `FK_FORNECEDOR_PRODUTO` (`COD_FORNECEDOR`),
  KEY `FK_UNIDADE_PRODUTO` (`COD_UNIDADE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table produto
#

LOCK TABLES `produto` WRITE;
/*!40000 ALTER TABLE `produto` DISABLE KEYS */;
INSERT INTO `produto` VALUES ('1',1,NULL,'Pilha Amarela',0.25,0.5,NULL,10);
INSERT INTO `produto` VALUES ('1010',3,1,'Refrigerante Coca Cola 2lt',2.25,3.5,NULL,10);
INSERT INTO `produto` VALUES ('1011',3,1,'Refrigerante Pepsi Cola 2lt',2.1,3.25,NULL,10);
INSERT INTO `produto` VALUES ('1012',3,1,'Refrigerante Fanta Uva 2lt',2,3,NULL,10);
INSERT INTO `produto` VALUES ('1013',3,1,'Refrigente Fruki Cola 2lt',1.9,2.5,NULL,10);
INSERT INTO `produto` VALUES ('1014',3,1,'Refrigerante Guarana Antartica 2lt',2,2.9,NULL,10);
INSERT INTO `produto` VALUES ('111111',1,12,'Teste 2',2,5,NULL,10);
INSERT INTO `produto` VALUES ('11111111',3,1,'Pretinha',0,560,NULL,1);
INSERT INTO `produto` VALUES ('111111111',1,1,'vaca loca',100,150,NULL,10);
INSERT INTO `produto` VALUES ('1111111111',1,12,'Cachorro',400,500,NULL,100);
INSERT INTO `produto` VALUES ('2',1,NULL,'Pistache',1,2,NULL,20);
INSERT INTO `produto` VALUES ('2222222',2,1,'aaaaaaa',1,2,NULL,1);
INSERT INTO `produto` VALUES ('555',1,2,'Teste',500,1000,NULL,10);
INSERT INTO `produto` VALUES ('55555',3,2,'XXXXXYYW',1,2,NULL,2);
INSERT INTO `produto` VALUES ('99999999',3,1,'Pretinha',0,560,NULL,1);
INSERT INTO `produto` VALUES ('dfdf',3,2,'dfdf',2,2,NULL,1);
INSERT INTO `produto` VALUES ('fdf',1,NULL,'dfdf',1,2,NULL,10);
INSERT INTO `produto` VALUES ('sasas',2,NULL,'asasas',33,233,NULL,555);
/*!40000 ALTER TABLE `produto` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table recebimento
#

DROP TABLE IF EXISTS `recebimento`;
CREATE TABLE `recebimento` (
  `COD_RECEBIMENTO` int(11) NOT NULL auto_increment,
  `COD_BANCO` int(11) default NULL,
  `COD_TIPO_PGTO` int(11) default NULL,
  `COD_CLIENTE` int(11) default NULL COMMENT 'codigo do cliente - auto-incremento',
  `NUM_DOCUMENTO` varchar(20) default NULL,
  `VLR_TOTAL_RECEBIMENTO` double(11,2) default NULL,
  `VLR_JURO_RECEBIMENTO` double(11,2) default NULL,
  `VLR_MULTA_RECEBIMENTO` double(11,2) default NULL,
  `VLR_DESCONTO_RECEBIMENTO` double(11,2) default NULL,
  `VLR_RECEBIDO` double(11,2) default NULL,
  `EMISSAO_RECEBIMENTO` date default NULL,
  `LANCAMENTO_RECEBIMENTO` date default NULL,
  `VENCIMENTO_RECEBIMENTO` date default NULL,
  `DATA_RECEBIMENTO` date default NULL,
  PRIMARY KEY  (`COD_RECEBIMENTO`),
  KEY `FK_BANCO_RECEBIMENTO` (`COD_BANCO`),
  KEY `FK_CLIENTE_RECEBIMENTO` (`COD_CLIENTE`),
  KEY `FK_TIPO_PGTO_RECEBIMENTO` (`COD_TIPO_PGTO`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

#
# Dumping data for table recebimento
#

LOCK TABLES `recebimento` WRITE;
/*!40000 ALTER TABLE `recebimento` DISABLE KEYS */;
INSERT INTO `recebimento` VALUES (1,1,1,1,'123',100,10,10,5,115,'2008-01-01','2008-01-05','2008-01-15','2008-01-31');
INSERT INTO `recebimento` VALUES (4,NULL,NULL,1,'RECIBO',50,525,NULL,NULL,NULL,NULL,NULL,'2008-11-12',NULL);
/*!40000 ALTER TABLE `recebimento` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table req_cab
#

DROP TABLE IF EXISTS `req_cab`;
CREATE TABLE `req_cab` (
  `COD_REQ_CAB` int(11) NOT NULL auto_increment,
  `COD_FUNCIONARIO` int(11) default NULL,
  `DATA_REQ_CAB` date default NULL,
  PRIMARY KEY  (`COD_REQ_CAB`),
  KEY `FK_FUNCIONARIO_REQ_CAB` (`COD_FUNCIONARIO`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

#
# Dumping data for table req_cab
#

LOCK TABLES `req_cab` WRITE;
/*!40000 ALTER TABLE `req_cab` DISABLE KEYS */;
INSERT INTO `req_cab` VALUES (1,1,'2011-11-02');
INSERT INTO `req_cab` VALUES (2,1,NULL);
/*!40000 ALTER TABLE `req_cab` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table req_det
#

DROP TABLE IF EXISTS `req_det`;
CREATE TABLE `req_det` (
  `COD_PRODUTO` varchar(13) NOT NULL,
  `COD_REQ_CAB` int(11) NOT NULL,
  `QTDE_REQ_DET` int(11) default NULL,
  `VLR_UNIT_REQ_DET` double(11,2) default NULL,
  `VLR_TOTAL_REQ_DET` double(11,2) default NULL,
  `FLAG` char(1) default NULL,
  PRIMARY KEY  (`COD_PRODUTO`,`COD_REQ_CAB`),
  KEY `FK_REQ_CAB_REQ_DET` (`COD_REQ_CAB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table req_det
#

LOCK TABLES `req_det` WRITE;
/*!40000 ALTER TABLE `req_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_det` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table req_det_2
#

DROP TABLE IF EXISTS `req_det_2`;
CREATE TABLE `req_det_2` (
  `COD_PRODUTO` varchar(13) NOT NULL default '',
  `COD_REQ_CAB` int(11) NOT NULL default '0',
  PRIMARY KEY  (`COD_PRODUTO`,`COD_REQ_CAB`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table req_det_2
#

LOCK TABLES `req_det_2` WRITE;
/*!40000 ALTER TABLE `req_det_2` DISABLE KEYS */;
INSERT INTO `req_det_2` VALUES ('1111111111111',1);
INSERT INTO `req_det_2` VALUES ('2222222222222',2);
/*!40000 ALTER TABLE `req_det_2` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table tipo_pgto
#

DROP TABLE IF EXISTS `tipo_pgto`;
CREATE TABLE `tipo_pgto` (
  `COD_TIPO_PGTO` int(11) NOT NULL auto_increment,
  `DESCRICAO_TIPO_PGTO` varchar(20) default NULL,
  PRIMARY KEY  (`COD_TIPO_PGTO`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

#
# Dumping data for table tipo_pgto
#

LOCK TABLES `tipo_pgto` WRITE;
/*!40000 ALTER TABLE `tipo_pgto` DISABLE KEYS */;
INSERT INTO `tipo_pgto` VALUES (1,'DINHEIRO');
INSERT INTO `tipo_pgto` VALUES (2,'CARTAO');
INSERT INTO `tipo_pgto` VALUES (3,'CHEQUE');
INSERT INTO `tipo_pgto` VALUES (4,'Preta');
/*!40000 ALTER TABLE `tipo_pgto` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table unidade
#

DROP TABLE IF EXISTS `unidade`;
CREATE TABLE `unidade` (
  `COD_UNIDADE` int(11) NOT NULL auto_increment,
  `DESCRICAO_UNIDADE` char(5) default NULL,
  PRIMARY KEY  (`COD_UNIDADE`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COMMENT='armazena as diversas unidades dos produtos';

#
# Dumping data for table unidade
#

LOCK TABLES `unidade` WRITE;
/*!40000 ALTER TABLE `unidade` DISABLE KEYS */;
INSERT INTO `unidade` VALUES (1,'CX');
INSERT INTO `unidade` VALUES (2,'LT');
INSERT INTO `unidade` VALUES (3,'UND');
/*!40000 ALTER TABLE `unidade` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table venda_cab
#

DROP TABLE IF EXISTS `venda_cab`;
CREATE TABLE `venda_cab` (
  `COD_VENDA_CAB` int(11) NOT NULL auto_increment,
  `COD_CLIENTE` int(11) default NULL COMMENT 'codigo do cliente - auto-incremento',
  `COD_CARTAO` int(11) default NULL,
  `COD_FUNCIONARIO` int(11) default NULL,
  `COD_TIPO_PGTO` int(11) default NULL,
  `COD_CFOP` int(11) default NULL,
  `DATA_VENDA_CAB` varchar(10) default NULL,
  `VLR_VENDA_CAB` double(11,2) default NULL,
  `DESCONTO_VENDA_CAB` double(11,2) default NULL,
  `TOTAL_VENDA_CAB` double(11,2) default NULL,
  `NUM_PARCELAS_VENDA_CAB` int(11) default NULL,
  `PRI_VENC_VENDA_CAB` varchar(10) default NULL,
  `NUM_NF_VENDA_CAB` int(11) default NULL,
  PRIMARY KEY  (`COD_VENDA_CAB`),
  KEY `FK_CARTAO_VENDA_CAB` (`COD_CARTAO`),
  KEY `FK_CFOP_VENDA_CAB` (`COD_CFOP`),
  KEY `FK_CLIENTE_VENDA_CAB` (`COD_CLIENTE`),
  KEY `FK_FUNCIONARIO_VENDA_CAB` (`COD_FUNCIONARIO`),
  KEY `FK_TIPO_PGTO_VENDA_CAB` (`COD_TIPO_PGTO`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;

#
# Dumping data for table venda_cab
#

LOCK TABLES `venda_cab` WRITE;
/*!40000 ALTER TABLE `venda_cab` DISABLE KEYS */;
INSERT INTO `venda_cab` VALUES (2,1,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,423);
INSERT INTO `venda_cab` VALUES (3,8,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,100);
INSERT INTO `venda_cab` VALUES (5,8,NULL,1,1,NULL,'10/12/2011',NULL,NULL,NULL,NULL,NULL,175);
INSERT INTO `venda_cab` VALUES (6,8,NULL,1,1,NULL,'21/05/2011',NULL,NULL,NULL,NULL,NULL,7845);
INSERT INTO `venda_cab` VALUES (7,8,NULL,1,1,NULL,'21/12/2011',NULL,NULL,NULL,NULL,NULL,7845);
INSERT INTO `venda_cab` VALUES (8,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (9,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (10,8,NULL,1,1,NULL,'31/31/2011',NULL,NULL,NULL,NULL,NULL,666);
INSERT INTO `venda_cab` VALUES (11,8,NULL,1,1,NULL,'31/31/2031',550,50,500,NULL,NULL,666);
INSERT INTO `venda_cab` VALUES (15,8,NULL,1,1,NULL,'11/11/1111',351.5,0,351.5,NULL,'11/11/1111',6666);
INSERT INTO `venda_cab` VALUES (20,8,NULL,1,1,NULL,'11/11/1111',292500,2500,290000,NULL,'22/22/2222',NULL);
INSERT INTO `venda_cab` VALUES (22,8,NULL,1,2,NULL,'11/11/1111',NULL,NULL,NULL,5,'22/22/2222',NULL);
INSERT INTO `venda_cab` VALUES (28,8,NULL,4,1,NULL,'25/09/1992',NULL,NULL,NULL,NULL,'30/12/1992',NULL);
INSERT INTO `venda_cab` VALUES (29,8,NULL,1,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (30,8,NULL,1,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (31,8,NULL,1,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (32,8,NULL,1,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (33,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (34,8,2,1,2,NULL,'11/11/1111',NULL,NULL,NULL,5,'22/22/2222',666666666);
INSERT INTO `venda_cab` VALUES (35,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (36,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (37,8,NULL,1,1,NULL,NULL,118,8,110,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (38,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (40,8,1,1,2,NULL,'11/11/1111',NULL,NULL,NULL,NULL,'21/05/2011',154875);
INSERT INTO `venda_cab` VALUES (41,8,NULL,1,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (42,1,NULL,5,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (43,1,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (45,1,NULL,2,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (46,8,NULL,4,1,NULL,'11/11/1111',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (47,8,NULL,2,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (48,8,NULL,2,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (49,8,NULL,2,1,NULL,'24/02/2011',40,10,30,NULL,'00/00/0000',NULL);
INSERT INTO `venda_cab` VALUES (50,8,NULL,4,1,NULL,'11/11/1111',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (51,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (52,8,NULL,2,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (53,8,NULL,4,1,NULL,'11/11/1111',3.5,0,3.5,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (54,8,NULL,4,NULL,NULL,'  /  /    ',16.25,0,16.25,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (55,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (56,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (57,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (58,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (59,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (60,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (61,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (62,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (63,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (64,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (65,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (66,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (67,8,NULL,4,NULL,NULL,'  /  /    ',45,0,45,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (68,8,NULL,4,1,NULL,'11/11/1111',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (69,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (70,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (72,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (73,8,NULL,4,1,NULL,'20/11/2011',52.5,2.5,50,NULL,'  /  /    ',NULL);
INSERT INTO `venda_cab` VALUES (74,8,NULL,2,NULL,NULL,'20/11/2011',2752.75,0,2752.75,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (76,8,NULL,2,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (77,8,NULL,2,NULL,NULL,'  /  /    ',335,0,335,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (78,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (79,8,NULL,2,1,NULL,'11/11/1111',NULL,NULL,NULL,NULL,'  /  /    ',123);
INSERT INTO `venda_cab` VALUES (80,8,NULL,1,1,NULL,'11/11/1111',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (81,8,NULL,1,1,NULL,'11/11/1111',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (82,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (83,8,NULL,4,NULL,NULL,'  /  /    ',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (84,8,NULL,1,1,NULL,'11/11/1111',52.5,0,52.5,NULL,NULL,NULL);
INSERT INTO `venda_cab` VALUES (85,1,1,1,1,NULL,'11/11/1111',2800,0,2800,1,'15/11/1111',NULL);
/*!40000 ALTER TABLE `venda_cab` ENABLE KEYS */;
UNLOCK TABLES;

#
# Source for table venda_det
#

DROP TABLE IF EXISTS `venda_det`;
CREATE TABLE `venda_det` (
  `COD_VENDA_CAB` int(11) NOT NULL,
  `COD_PRODUTO` varchar(13) NOT NULL,
  `QTDE_VENDA_DET` int(11) default NULL,
  `VLR_UNIT_VENDA_DET` double(11,2) default NULL,
  `VLR_TOTAL_VENDA_DET` double(11,2) default NULL,
  PRIMARY KEY  (`COD_VENDA_CAB`,`COD_PRODUTO`),
  KEY `FK_PRODUTO_VENDA_DET` (`COD_PRODUTO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Dumping data for table venda_det
#

LOCK TABLES `venda_det` WRITE;
/*!40000 ALTER TABLE `venda_det` DISABLE KEYS */;
INSERT INTO `venda_det` VALUES (2,'1010',NULL,3.5,NULL);
INSERT INTO `venda_det` VALUES (10,'1010',NULL,3.5,NULL);
INSERT INTO `venda_det` VALUES (11,'1010',10,3.5,35);
INSERT INTO `venda_det` VALUES (11,'1012',5,3,15);
INSERT INTO `venda_det` VALUES (11,'1111111111',1,500,500);
INSERT INTO `venda_det` VALUES (15,'1',100,0.5,50);
INSERT INTO `venda_det` VALUES (15,'1010',60,3.5,210);
INSERT INTO `venda_det` VALUES (15,'1011',10,3.25,32.5);
INSERT INTO `venda_det` VALUES (15,'1014',10,2.9,29);
INSERT INTO `venda_det` VALUES (15,'2',15,2,30);
INSERT INTO `venda_det` VALUES (20,'1011',90000,3.25,292500);
INSERT INTO `venda_det` VALUES (28,'1010',NULL,3.5,NULL);
INSERT INTO `venda_det` VALUES (28,'1011',NULL,3.25,NULL);
INSERT INTO `venda_det` VALUES (30,'1011',NULL,3.25,NULL);
INSERT INTO `venda_det` VALUES (32,'1013',NULL,2.5,NULL);
INSERT INTO `venda_det` VALUES (33,'1011',NULL,3.25,NULL);
INSERT INTO `venda_det` VALUES (33,'1013',NULL,2.5,NULL);
INSERT INTO `venda_det` VALUES (37,'1010',10,3.5,35);
INSERT INTO `venda_det` VALUES (37,'1013',10,2.5,25);
INSERT INTO `venda_det` VALUES (37,'1014',20,2.9,58);
INSERT INTO `venda_det` VALUES (40,'1010',NULL,3.5,NULL);
INSERT INTO `venda_det` VALUES (40,'111111',NULL,5,NULL);
INSERT INTO `venda_det` VALUES (42,'1011',NULL,3.25,NULL);
INSERT INTO `venda_det` VALUES (42,'1013',NULL,2.5,NULL);
INSERT INTO `venda_det` VALUES (43,'1011',NULL,3.25,NULL);
INSERT INTO `venda_det` VALUES (43,'1014',NULL,2.9,NULL);
INSERT INTO `venda_det` VALUES (46,'1010',NULL,3.5,NULL);
INSERT INTO `venda_det` VALUES (47,'1010',NULL,3.5,NULL);
INSERT INTO `venda_det` VALUES (49,'1',10,0.5,5);
INSERT INTO `venda_det` VALUES (49,'1010',10,3.5,35);
INSERT INTO `venda_det` VALUES (53,'1013',NULL,2.5,NULL);
INSERT INTO `venda_det` VALUES (54,'1011',5,3.25,16.25);
INSERT INTO `venda_det` VALUES (67,'1012',15,3,45);
INSERT INTO `venda_det` VALUES (73,'1010',15,3.5,52.5);
INSERT INTO `venda_det` VALUES (74,'1011',847,3.25,2752.75);
INSERT INTO `venda_det` VALUES (76,'1012',NULL,3,NULL);
INSERT INTO `venda_det` VALUES (76,'1013',NULL,2.5,NULL);
INSERT INTO `venda_det` VALUES (77,'1010',60,3.5,210);
INSERT INTO `venda_det` VALUES (77,'1013',50,2.5,125);
INSERT INTO `venda_det` VALUES (84,'1010',15,3.5,52.5);
INSERT INTO `venda_det` VALUES (85,'11111111',5,560,2800);
/*!40000 ALTER TABLE `venda_det` ENABLE KEYS */;
UNLOCK TABLES;

#
#  Foreign keys for table cliente_endereco
#

ALTER TABLE `cliente_endereco`
ADD CONSTRAINT `FK_CLIENTE_ENDERECO` FOREIGN KEY (`COD_CLIENTE`) REFERENCES `cliente` (`COD_CLIENTE`);

#
#  Foreign keys for table cliente_telefone
#

ALTER TABLE `cliente_telefone`
ADD CONSTRAINT `FK_CLIENTE_TELEFONE` FOREIGN KEY (`COD_CLIENTE`) REFERENCES `cliente` (`COD_CLIENTE`);

#
#  Foreign keys for table cobranca
#

ALTER TABLE `cobranca`
ADD CONSTRAINT `FK_CLIENTE_COBRANCA` FOREIGN KEY (`COD_CLIENTE`) REFERENCES `cliente` (`COD_CLIENTE`);

#
#  Foreign keys for table cot_det
#

ALTER TABLE `cot_det`
ADD CONSTRAINT `FK_COT_CAB_COT_DET` FOREIGN KEY (`COD_COT_CAB`) REFERENCES `cot_cab` (`COD_COT_CAB`),
ADD CONSTRAINT `FK_REQ_DET_COT_DET` FOREIGN KEY (`COD_PRODUTO`, `COD_REQ_CAB`) REFERENCES `req_det_2` (`COD_PRODUTO`, `COD_REQ_CAB`);

#
#  Foreign keys for table funcionario
#

ALTER TABLE `funcionario`
ADD CONSTRAINT `FK_DEPARTAMENTO_FUNCIONARIO` FOREIGN KEY (`COD_DEPARTAMENTO`) REFERENCES `departamento` (`COD_DEPARTAMENTO`);

#
#  Foreign keys for table movimento
#

ALTER TABLE `movimento`
ADD CONSTRAINT `FK_PLANO_CONTA_MOVIMENTO` FOREIGN KEY (`COD_PLANO_CONTA`) REFERENCES `plano_conta` (`COD_PLANO_CONTA`);

#
#  Foreign keys for table nfe_cab
#

ALTER TABLE `nfe_cab`
ADD CONSTRAINT `FK_CFOP_NFE_CAB` FOREIGN KEY (`COD_CFOP`) REFERENCES `cfop` (`COD_CFOP`),
ADD CONSTRAINT `FK_FORNECEDOR_NFE_CAB` FOREIGN KEY (`COD_FORNECEDOR`) REFERENCES `fornecedor` (`COD_FORNECEDOR`);

#
#  Foreign keys for table nfe_det
#

ALTER TABLE `nfe_det`
ADD CONSTRAINT `FK_NFE_CAB_NFE_DET` FOREIGN KEY (`NUMERO_NFE_CAB`) REFERENCES `nfe_cab` (`NUMERO_NFE_CAB`),
ADD CONSTRAINT `FK_PRODUTO_NFE_DET` FOREIGN KEY (`COD_PRODUTO`) REFERENCES `produto` (`COD_PRODUTO`);

#
#  Foreign keys for table orc_cab
#

ALTER TABLE `orc_cab`
ADD CONSTRAINT `FK_CLIENTE_ORC_CAB` FOREIGN KEY (`COD_CLIENTE`) REFERENCES `cliente` (`COD_CLIENTE`),
ADD CONSTRAINT `FK_FUNCIONARIO_ORC_CAB` FOREIGN KEY (`COD_FUNCIONARIO`) REFERENCES `funcionario` (`COD_FUNCIONARIO`);

#
#  Foreign keys for table orc_det
#

ALTER TABLE `orc_det`
ADD CONSTRAINT `FK_ORC_CAB_ORC_DET` FOREIGN KEY (`COD_ORC_CAB`) REFERENCES `orc_cab` (`COD_ORC_CAB`),
ADD CONSTRAINT `FK_PRODUTO_ORC_DET` FOREIGN KEY (`COD_PRODUTO`) REFERENCES `produto` (`COD_PRODUTO`);

#
#  Foreign keys for table pagamento
#

ALTER TABLE `pagamento`
ADD CONSTRAINT `FK_BANCO_PAGAMENTO` FOREIGN KEY (`COD_BANCO`) REFERENCES `banco` (`COD_BANCO`),
ADD CONSTRAINT `FK_FORNECEDOR_PAGAMENTO` FOREIGN KEY (`COD_FORNECEDOR`) REFERENCES `fornecedor` (`COD_FORNECEDOR`),
ADD CONSTRAINT `FK_PLANO_CONTA_PAGAMENTO` FOREIGN KEY (`COD_PLANO_CONTA`) REFERENCES `plano_conta` (`COD_PLANO_CONTA`),
ADD CONSTRAINT `FK_TIPO_PGTO_PAGAMENTO` FOREIGN KEY (`COD_TIPO_PGTO`) REFERENCES `tipo_pgto` (`COD_TIPO_PGTO`);

#
#  Foreign keys for table pedido_cab
#

ALTER TABLE `pedido_cab`
ADD CONSTRAINT `FK_COT_CAB_PEDIDO_CAB` FOREIGN KEY (`COD_COT_CAB`) REFERENCES `cot_cab` (`COD_COT_CAB`),
ADD CONSTRAINT `FK_FORNECEDOR_PEDIDO_CAB` FOREIGN KEY (`COD_FORNECEDOR`) REFERENCES `fornecedor` (`COD_FORNECEDOR`);

#
#  Foreign keys for table pedido_det
#

ALTER TABLE `pedido_det`
ADD CONSTRAINT `FK_COT_DET_PEDIDO_DET` FOREIGN KEY (`COD_COT_CAB`, `COD_PRODUTO`, `COD_REQ_CAB`) REFERENCES `cot_det` (`COD_COT_CAB`, `COD_PRODUTO`, `COD_REQ_CAB`),
ADD CONSTRAINT `FK_PEDIDO_CAB_PEDIDO_DET` FOREIGN KEY (`COD_PEDIDO_CAB`) REFERENCES `pedido_cab` (`COD_PEDIDO_CAB`);

#
#  Foreign keys for table produto
#

ALTER TABLE `produto`
ADD CONSTRAINT `FK_FORNECEDOR_PRODUTO` FOREIGN KEY (`COD_FORNECEDOR`) REFERENCES `fornecedor` (`COD_FORNECEDOR`),
ADD CONSTRAINT `FK_UNIDADE_PRODUTO` FOREIGN KEY (`COD_UNIDADE`) REFERENCES `unidade` (`COD_UNIDADE`);

#
#  Foreign keys for table recebimento
#

ALTER TABLE `recebimento`
ADD CONSTRAINT `FK_BANCO_RECEBIMENTO` FOREIGN KEY (`COD_BANCO`) REFERENCES `banco` (`COD_BANCO`),
ADD CONSTRAINT `FK_CLIENTE_RECEBIMENTO` FOREIGN KEY (`COD_CLIENTE`) REFERENCES `cliente` (`COD_CLIENTE`),
ADD CONSTRAINT `FK_TIPO_PGTO_RECEBIMENTO` FOREIGN KEY (`COD_TIPO_PGTO`) REFERENCES `tipo_pgto` (`COD_TIPO_PGTO`);

#
#  Foreign keys for table req_cab
#

ALTER TABLE `req_cab`
ADD CONSTRAINT `FK_FUNCIONARIO_REQ_CAB` FOREIGN KEY (`COD_FUNCIONARIO`) REFERENCES `funcionario` (`COD_FUNCIONARIO`);

#
#  Foreign keys for table req_det
#

ALTER TABLE `req_det`
ADD CONSTRAINT `FK_PRODUTO_REQ_DET` FOREIGN KEY (`COD_PRODUTO`) REFERENCES `produto` (`COD_PRODUTO`),
ADD CONSTRAINT `FK_REQ_CAB_REQ_DET` FOREIGN KEY (`COD_REQ_CAB`) REFERENCES `req_cab` (`COD_REQ_CAB`);

#
#  Foreign keys for table venda_cab
#

ALTER TABLE `venda_cab`
ADD CONSTRAINT `FK_CARTAO_VENDA_CAB` FOREIGN KEY (`COD_CARTAO`) REFERENCES `cartao` (`COD_CARTAO`),
ADD CONSTRAINT `FK_CFOP_VENDA_CAB` FOREIGN KEY (`COD_CFOP`) REFERENCES `cfop` (`COD_CFOP`),
ADD CONSTRAINT `FK_CLIENTE_VENDA_CAB` FOREIGN KEY (`COD_CLIENTE`) REFERENCES `cliente` (`COD_CLIENTE`),
ADD CONSTRAINT `FK_FUNCIONARIO_VENDA_CAB` FOREIGN KEY (`COD_FUNCIONARIO`) REFERENCES `funcionario` (`COD_FUNCIONARIO`),
ADD CONSTRAINT `FK_TIPO_PGTO_VENDA_CAB` FOREIGN KEY (`COD_TIPO_PGTO`) REFERENCES `tipo_pgto` (`COD_TIPO_PGTO`);

#
#  Foreign keys for table venda_det
#

ALTER TABLE `venda_det`
ADD CONSTRAINT `FK_PRODUTO_VENDA_DET` FOREIGN KEY (`COD_PRODUTO`) REFERENCES `produto` (`COD_PRODUTO`),
ADD CONSTRAINT `FK_VENDA_CAB_VENDA_DET` FOREIGN KEY (`COD_VENDA_CAB`) REFERENCES `venda_cab` (`COD_VENDA_CAB`);


/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
